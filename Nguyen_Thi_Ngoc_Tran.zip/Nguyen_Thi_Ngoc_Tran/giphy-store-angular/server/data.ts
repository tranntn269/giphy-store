import { User, Tag, Gif } from './../src/app/modules/features/main/models';

const users: User[] = [
  {
    "username": "username1",
    "password": "123456"
  },
  {
    "username": "username2",
    "password": "123456"
  },
  {
    "username": "username3",
    "password": "123456"
  },
];

const tags: Tag[] = [
  {
    id: 1,
    name: 'steak'
  },

  {
    id: 2,
    name: 'foods'
  },
  {
    id: 3,
    name: 'spicy noodles'
  },
  {
    id: 4,
    name: 'chicken wings'
  },

  {
    id: 5,
    name: 'anime'
  },
  {
    id: 6,
    name: 'cartoon'
  },
  {
    id: 7,
    name: 'tokyo ghoul'
  },
  {
    id: 8,
    name: 'kaneki'
  },
  {
    id: 9,
    name: 'black butler'
  }, {
    id: 10,
    name: 'sebastian'
  },
  {
    id: 11,
    name: 'others'
  },
  {
    id: 12,
    name: 'one piece'
  },
  {
    id: 13,
    name: 'characters'
  },
  {
    id: 14,
    name: 'yummy'
  },
  {
    id: 15,
    name: 'favorite'
  },
  {
    id: 16,
    name: 'mukbang'
  },
  {
    id: 17,
    name: 'seals'
  },
  {
    id: 18,
    name: 'dog'
  },
  {
    id: 19,
    name: 'animal'
  },
  //them
  {
    id: 20,
    name: 'holoday'
  },
  {
    id: 21,
    name: 'new year eve'
  },
  {
    id: 22,
    name: 'christmas'
  },

];


const gifs: Gif[] = [
  {
    id: 1,
    slug: "sing-me-to-sleep",
    title: "Sing me to sleep",
    url: "https://i.giphy.com/media/YplU9clewjzd9jFzek/giphy.webp",
    username: 'username1',
    tags: ["others"],
    createdAt: 1609734757,
    lastUpdated: 1609734757,
    rating: 9.6
  },
  {
    id: 2,
    slug: "new-year-love",
    title: "New Year Love",
    url: "https://i.giphy.com/media/xT0xeyDaXy0vVDwR8I/giphy.webp",
    username: 'username1',
    tags: ["others"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 3,
    slug: "new-year-chirstmas",
    title: "New Year Christmas ",
    url: "https://i.giphy.com/media/VueOgqd6TnUPpfDui5/giphy.webp",
    username: 'username1',
    tags: ["others"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 4,
    slug: "white-dog",
    title: "White Dog",
    url: "https://i.giphy.com/media/4Zo41lhzKt6iZ8xff9/giphy.webp",
    username: 'username2',
    tags: ["dog"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 5,
    slug: "mr-bean-eating",
    title: "Mr Bean Eating",
    url: "https://i.giphy.com/media/14sNkocXYaH6i4/giphy.webp",
    username: 'username2',
    tags: ['chicken wings'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 6,
    slug: "fried-chicken-dip",
    title: "Fried Chicken Dip",
    url: "https://media0.giphy.com/media/35MvUTdVqQcklfbuKf/giphy.gif?cid=790b76115eb5bab63fa970049e58c23e0dcb2a260b046f62&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ['chicken wings'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 7,
    slug: "chicken-wings-the-making-of-concrete-and-gold",
    title: "Chicken Wings The Making Of Concrete And Gold",
    url: "https://media4.giphy.com/media/3ohhwhICyqqW7gd3A4/giphy.gif?cid=790b7611603bbefa741aa54b276e9b58faa0801a5f6236b9&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ['chicken wings'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 8,
    slug: "fried-chicken-love",
    title: "Fried Chicken Love",
    url: "https://i.giphy.com/media/E1LNza0pgvf6WXv88B/giphy.webp",
    username: 'username1',
    tags: ['chicken wings'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 9,
    slug: "sanders-colonel",
    title: "Fried Chicken GIF By KFC India",
    url: "https://i.giphy.com/media/3s6IpIQkPRI9wDT2QB/giphy.webp",
    username: 'username1',
    tags: ['chicken wings'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 10,
    slug: "southparkgifs",
    title: "Fried Chicken GIF By South Park",
    url: "https://media1.giphy.com/media/l2SpXskLsXAqGiyK4/giphy.gif?cid=790b761171205a19f2ebcbd1a6d0214f4b1f6924d158dc03&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ['chicken wings'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 11,
    slug: "popeyeschicken-chicken-fried-biscuits",
    title: "Hungry Fried Chicken GIF By Popeyes Chicken",
    url: "https://i.giphy.com/media/JsyqMbEuqA1kkE8NMG/giphy.webp",
    username: 'username1',
    tags: ['chicken wings'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 12,
    slug: "jerseyshore-jersey-shore-family-vacation-tendies",
    title: "Hungry Jersey Shore",
    url: "https://i.giphy.com/media/FoRFnTD7RSbzBUtYhO/giphy.webp",
    username: 'username1',
    tags: ['chicken wings'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 13,
    slug: "crackerbarrel-hungry-emotion-greeting",
    title: "Hungry Fried Chicken GIF By Cracker Barrel",
    url: "https://i.giphy.com/media/kPgcBqi3RAvzDNT2Y3/giphy.webp",
    username: 'username1',
    tags: ['chicken wings'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },

  {
    id: 14,
    slug: "funimation-tokyo-ghoul-clowns-re",
    title: "Tokyo Ghoul Clowns",
    url: "https://media2.giphy.com/media/kEoVI1N04lnAvSUF7t/giphy.gif?cid=ecf05e47ffyhb26si026fvbe8mddbmw1lodi1w5hxv2o5c0q&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ['tokyo ghoul', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },

  {
    id: 15,
    slug: "tokyo-ghoul-root-a-suzuya-juuzou",
    title: "Tokyo Ghoul Juuzou Suzuya",
    url: "https://i.giphy.com/media/B9NqGIgBw4ka4/giphy.webp",
    username: 'username1',
    tags: ['tokyo ghoul', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 16,
    slug: "tokyo-ghoul-touka-kirishima-tgedit",
    title: "Tokyo Ghoul Touka Kirishima",
    url: "https://media3.giphy.com/media/letvYyQtQqY12/giphy.gif?cid=790b7611e55972c1e37aadd2337d8dfd5ef5313fa6c67603&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ['tokyo ghoul', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 17,
    slug: "mannyjammy-tokyo-ghoul",
    title: "Tokyo Ghoul Apple",
    url: "https://media1.giphy.com/media/5ns61xKTssJGUbMJfz/giphy.gif?cid=790b76111ee9121c5e029f2da07526a5e4833c246eb36a5f&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ['tokyo ghoul', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 18,
    slug: "national-coffee-day-tokyo-ghoul-tsukiyama-shuu",
    title: "Tokyo Ghoul National Coffee Day",
    url: "https://i.giphy.com/media/vtuqbkOw2TUWI/giphy.webp",
    username: 'username1',
    tags: ['tokyo ghoul', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },

  {
    id: 19,
    slug: "tokyo-ghoul-touka-kirishima",
    title: "Tokyo Ghoul Touka Kirishima",
    url: "https://i.giphy.com/media/Oe5bIBMkdUaEo/giphy.webp",
    username: 'username1',
    tags: ['tokyo ghoul', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },

  {
    id: 20,
    slug: "alissandra-sementilli-anime-tokyo-ghoul",
    title: "Tokyo Ghoul GIF By Alissandra",
    url: "https://media0.giphy.com/media/fZ93CIL1OtOVmDJ0X7/giphy.gif?cid=790b761140a88d0ba9b65ff6bc33b6578b4000973251e41d&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ['tokyo ghoul', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 21,
    slug: "funimation-tokyo-ghoul-shachi",
    title: "Tokyo Ghoul Punch",
    url: "https://media2.giphy.com/media/8hZoGLl6w8moYDInhY/giphy.gif?cid=790b761168a9e7258233ac6d036752e2e27514932f269893&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ['tokyo ghoul', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 22,
    slug: "funimation-dancing-2A0jTIDgigtGRvBXuW",
    title: "Tokyo Ghoul Dancing",
    url: "https://media1.giphy.com/media/2A0jTIDgigtGRvBXuW/giphy.gif?cid=790b761153131c3b3a8b16e74ea822e22baa72273386981a&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ['tokyo ghoul', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 23,
    slug: "tokyo-ghoul-kaneki-ken-kushu-SMVmV1TcnSUj6",
    title: "Tokyo Ghoul Rize Kamishiro",
    url: "https://i.giphy.com/media/SMVmV1TcnSUj6/giphy.webp",
    username: 'username1',
    tags: ['tokyo ghoul', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 24,
    slug: "funimation-cute-Yke71DdNck4qFd4LCi",
    title: "Tokyo Ghoul Flirting",
    url: "https://media3.giphy.com/media/Yke71DdNck4qFd4LCi/giphy.gif?cid=790b761145021f7bcc80bd56b68d20f30ee5fe8d1d87b66c&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ['tokyo ghoul', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 25,
    slug: "tk-Bu7qpLtWzXgkg",
    title: "Tk GIF crying",
    url: "https://media2.giphy.com/media/Bu7qpLtWzXgkg/giphy.gif?cid=790b7611dd7ec5c8c29c8178c5c9129f4be2dd8136faa5a0&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ['tokyo ghoul', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 26,
    slug: "re-I1XcOnOijO3iU",
    title: "Re Introduction GIF",
    url: "https://i.giphy.com/media/I1XcOnOijO3iU/giphy.webp",
    username: 'username1',
    tags: ['tokyo ghoul', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 27,
    slug: "tokyo-8UkaQtVBS2r8Q",
    title: "Touka is angry with Kaneki hihihi",
    url: "https://media2.giphy.com/media/8UkaQtVBS2r8Q/giphy.gif?cid=790b761150c8fadf858ebae18c86688bee072e3b8f8389fc&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ['tokyo ghoul', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 28,
    slug: "funimation-tokyo-ghoul-kaneki-touka-7YCAQ0EEpoz2qXnw3A",
    title: "Kaneki Tokyo Ghoul GIF By Funimation",
    url: "https://i.giphy.com/media/7YCAQ0EEpoz2qXnw3A/giphy.webp",
    username: 'username1',
    tags: ['tokyo ghoul', 'anime', 'cartoon', 'characters'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 29,
    slug: "ken-watanabe-2XLoAphEiufV6",
    title: "Kaneki Ken Watanabe GIF",
    url: "https://i.giphy.com/media/2XLoAphEiufV6/giphy.webp",
    username: 'username1',
    tags: ['kaneki', 'tokyo ghoul', 'anime', 'cartoon', 'characters'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 30,
    slug: "funimation-slap-iMCedi21L9MXg1gN43",
    title: "Kaneki Tokyo Ghoul Slap GIF By Funimation",
    url: "https://media1.giphy.com/media/iMCedi21L9MXg1gN43/giphy.gif?cid=790b7611812f7d1a7235cf6448283250783826734219e80b&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ['kaneki', 'tokyo ghoul', 'anime', 'cartoon', 'characters'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 31,
    slug: "tokyo-ghoul-kaneki-ken-root-a-pVwsBrZyxOlfa",
    title: "Kaneki Tokyo Ghoul Spoilers GIF",
    url: "https://i.giphy.com/media/pVwsBrZyxOlfa/giphy.webp",
    username: 'username1',
    tags: ['kaneki', 'tokyo ghoul', 'anime', 'cartoon', 'characters'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 32,
    slug: "analysis-oO5EueUxOSzpm",
    title: "Kaneki Analysis GIF",
    url: "https://i.giphy.com/media/oO5EueUxOSzpm/giphy.webp",
    username: 'username1',
    tags: ['kaneki', 'tokyo ghoul', 'anime', 'cartoon', 'characters'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 33,
    slug: "funimation-tokyo-ghoul-kaneki-root-a-BNgXhny4MvIeOG5fzG",
    title: "Kaneki Tokyo Ghoul GIF By Funimation",
    url: "https://i.giphy.com/media/BNgXhny4MvIeOG5fzG/giphy.webp",
    username: 'username1',
    tags: ['kaneki', 'tokyo ghoul', 'anime', 'cartoon', 'characters'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 34,
    slug: "funimation-tokyo-ghoul-kaneki-haise-sasaki-enrJj5p6lJD9WoFeg",
    title: "Kaneki Tokyo Ghoul Stress GIF By Funimation",
    url: "https://media1.giphy.com/media/enrJj5p6lJD9WoFegD/giphy.gif?cid=790b7611696c7922153770398d2533499f05fa28b1884b8c&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ['kaneki', 'tokyo ghoul', 'anime', 'cartoon', 'characters'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 35,
    slug: "funimation-tokyo-ghoul-kaneki-kakuja-kSbHxUlMNjmzPLXBGH",
    title: "Tokyo Ghoul Centipede GIF By Funimation",
    url: "https://media1.giphy.com/media/kSbHxUlMNjmzPLXBGH/giphy.gif?cid=790b76118417f783b0f1af9fb32d9991a91b7d0814674fab&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ['kaneki', 'tokyo ghoul', 'anime', 'cartoon', 'characters'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 36,
    slug: "challenge-amino-final-uFcRawfvGxsJO",
    title: "Kaneki So Cool Final Fight GIF",
    url: "https://i.giphy.com/media/uFcRawfvGxsJO/giphy.webp",
    username: 'username1',
    tags: ['kaneki', 'tokyo ghoul', 'anime', 'cartoon', 'characters'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 37,
    slug: "jason-qO5tf33zEIak0",
    title: "Tâsa",
    url: "https://media0.giphy.com/media/qO5tf33zEIak0/giphy.gif?cid=790b761185545fa654e93f540b6a268f34433d32e5d57f2c&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ['kaneki', 'tokyo ghoul', 'anime', 'cartoon', 'characters'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 38,
    slug: "tokyo-IQ2ZYHeDHbs4w",
    title: "Kaneki In The Sky",
    url: "https://i.giphy.com/media/IQ2ZYHeDHbs4w/giphy.webp",
    username: 'username1',
    tags: ['kaneki', 'tokyo ghoul', 'anime', 'cartoon', 'characters'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 39,
    slug: "ToeiAnimation-one-piece-luffy-gear-5",
    title: "One Piece Gear 5 GIF By Toei Animation",
    url: "https://i.giphy.com/media/WmkEhAIyWfpm1vdVcg/giphy.webp",
    username: 'username1',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 40,
    slug: "ToeiAnimation-one-piece-zoro-swords-4OV1bLOIWwIXRxpXlN",
    title: "Mad One Piece GIF By Toei Animation",
    url: "https://i.giphy.com/media/4OV1bLOIWwIXRxpXlN/giphy.webp",
    username: 'username1',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 41,
    slug: "one-piece-luffy-piratas-do-chapau-de-palha-DSxKEQoQix9hC",
    title: "Luffy with Hat One Piece GIF",
    url: "https://i.giphy.com/media/DSxKEQoQix9hC/giphy.webp",
    username: 'username1',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 42,
    slug: "one-piece-C3brYLms1bhv2",
    title: "Luffy Meat Meat Meat",
    url: "https://i.giphy.com/media/C3brYLms1bhv2/giphy.webp",
    username: 'username1',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 43,
    slug: "funimation-one-piece-squad-l3vRk0G0gLp2EQGoE",
    title: "One Piece Characters",
    url: "https://media2.giphy.com/media/l3vRk0G0gLp2EQGoE/giphy.gif?cid=790b7611f643cf8da9ad43ce9ddc7dd43c7f7a805f68484c&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 44,
    slug: "ToeiAnimation-sword-roronoa-zoro-swordman-OACHuKGkZ5F3FUbNsY",
    title: "One Piece Sword GIF By Toei Animation",
    url: "https://media1.giphy.com/media/OACHuKGkZ5F3FUbNsY/giphy.gif?cid=790b7611c07d5d85d54020f87256d6e9a2fefecf0380e379&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 45,
    slug: "one-piece-op-mg-2lSNErRCiZPck",
    title: "Chopper One Piece Op GIF",
    url: "https://i.giphy.com/media/2lSNErRCiZPck/giphy.webp",
    username: 'username2',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 46,
    slug: "cute-kawaii-jG186kNLKs6TS",
    title: "Chopper One Piece Eating GIF",
    url: "https://i.giphy.com/media/jG186kNLKs6TS/giphy.webp",
    username: 'username1',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 47,
    slug: "one-piece-manga-vplUlYHL0WnaE",
    title: "One Piece Manga GIF",
    url: "https://i.giphy.com/media/vplUlYHL0WnaE/giphy.webp",
    username: 'username1',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 48,
    slug: "one-piece-sanji-4yfGy8lw0xnCU",
    title: "Sanji One Piece GIF",
    url: "https://i.giphy.com/media/4yfGy8lw0xnCU/giphy.webp",
    username: 'username1',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 49,
    slug: "funimation-one-piece-super-4uMy0wqz6V1SM",
    title: "One Piece Super Dance GIF By Funimation",
    url: "https://i.giphy.com/media/4uMy0wqz6V1SM/giphy.webp",
    username: 'username1',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 50,
    slug: "one-piece-chopper-1ZwxP362AfHby",
    title: "Chopper One Piece Chopper GIF",
    url: "https://i.giphy.com/media/1ZwxP362AfHby/giphy.webp",
    username: 'username2',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 51,
    slug: "one-piece-luffy-7BW9U2cJPQZ0s",
    title: "Luffy Smile One Piece GIF",
    url: "https://i.giphy.com/media/T7Qx28nEdo9NK/giphy.webp",
    username: 'username1',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 52,
    slug: "TOEIAnimationUK-one-piece-luffy-ace-death-HFMPreKu5LfivtOmEI",
    title: "White Beard",
    url: "https://i.giphy.com/media/HFMPreKu5LfivtOmEI/giphy.webp",
    username: 'username2',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 53,
    slug: "one-piece-luffy-ace-TCGgBB4i5Y0OQ",
    title: "Ace One Piece Ace GIF",
    url: "https://i.giphy.com/media/TCGgBB4i5Y0OQ/giphy.webp",
    username: 'username1',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 54,
    slug: "one-piece-not-my-sanji-DMvXFFMFmoEmc",
    title: "Sanji One Piece GIF",
    url: "https://i.giphy.com/media/DMvXFFMFmoEmc/giphy.webp",
    username: 'username1',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 55,
    slug: "one-piece-luffy-SEaKNxJgOfU76",
    title: "Luffy One Piece GIF",
    url: "https://i.giphy.com/media/SEaKNxJgOfU76/giphy.webp",
    username: 'username1',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 56,
    slug: "one-piece-epic-princess-3P6rLkx3IWvjq",
    title: "Chopper One Piece Princess GIF",
    url: "https://i.giphy.com/media/3P6rLkx3IWvjq/giphy.webp",
    username: 'username2',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 57,
    slug: "one-piece-chopper-13Uqp5IGFpmDle",
    title: "One Piece Chopper GIF",
    url: "https://i.giphy.com/media/13Uqp5IGFpmDle/giphy.webp",
    username: 'username2',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 58,
    slug: "TOEIAnimationUK-one-piece-chopper-gif-lSgou3lYPvFA9w2fz3",
    title: "One Piece Chopper GIF By TOEI Animation UK",
    url: "https://i.giphy.com/media/lSgou3lYPvFA9w2fz3/giphy.webp",
    username: 'username2',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 59,
    slug: "TOEIAnimationUK-one-piece-chopper-gif-fVWFWTXjmcu4oxN2U0",
    title: "One Piece Chopper GIF By TOEI Animation UK",
    url: "https://i.giphy.com/media/fVWFWTXjmcu4oxN2U0/giphy.webp",
    username: 'username2',
    tags: ['one piece', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 60,
    slug: "black-butler-sebastian-michaelis-gif-YhqOIqAxz5qQo",
    title: "Black Butler Sebastian GIF",
    url: "https://i.giphy.com/media/YhqOIqAxz5qQo/giphy.webp",
    username: 'username1',
    tags: ['sebastian', ' black butler', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 61,
    slug: "black-butler-kuroshitsuji-sebastian-8Jx6fX471dcLC",
    title: "Black Butler Sebastian GIF",
    url: "https://i.giphy.com/media/8Jx6fX471dcLC/giphy.webp",
    username: 'username1',
    tags: ['sebastian', 'black butler', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 62,
    slug: "black-butler-sebastian-michaelis-gif-XfpOq1XjIuufS",
    title: "Sebastian Black Butler GIF",
    url: "https://i.giphy.com/media/XfpOq1XjIuufS/giphy.webp",
    username: 'username2',
    tags: ['sebastian', 'black butler', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 63,
    slug: "black-butler-kuroshitsuji-sebastian-CrdYskXS5ePq8",
    title: "Black Butler Sebastian GIF",
    url: "https://i.giphy.com/media/CrdYskXS5ePq8/giphy.webp",
    username: 'username2',
    tags: ['sebastian', 'black butler', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 64,
    slug: "black-butler-kuroshitsuji-sebastian-michaelis-fuL4cxJdRsHIs",
    title: "Sebastian Black Butler GIF",
    url: "https://i.giphy.com/media/fuL4cxJdRsHIs/giphy.webp",
    username: 'username2',
    tags: ['sebastian', 'black butler', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 65,
    slug: "funimation-black-butler-undertaker-9DwQ3VxeLvIKZKgqL3",
    title: "Undertaker Black Butler Undertaker GIF By Funimation",
    url: "https://i.giphy.com/media/9DwQ3VxeLvIKZKgqL3/giphy.webp",
    username: 'username2',
    tags: ['sebastian', 'black butler', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 66,
    slug: "black-butler-undertaker-gif-4buVC1pVuJISA",
    title: "Undertaker and his store",
    url: "https://i.giphy.com/media/4buVC1pVuJISA/giphy.webp",
    username: 'username1',
    tags: ['sebastian', 'black butler', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 67,
    slug: "black-butler-kuroshitsuji-grell-sutcliff-1CrMu9a7qDkty",
    title: "Black Butler Grell Sutcliff GIF",
    url: "https://i.giphy.com/media/1CrMu9a7qDkty/giphy.webp",
    username: 'username1',
    tags: ['sebastian', 'black butler', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 68,
    slug: "funimation-tea-black-butler-ctLn0QSvvfrxuFBh2n",
    title: "Black Butler Tea GIF By Funimation",
    url: "https://i.giphy.com/media/ctLn0QSvvfrxuFBh2n/giphy.webp",
    username: 'username1',
    tags: ['sebastian', 'black butler', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 69,
    slug: "funimation-happy-Rek2a4M1MVzO4hMhl1",
    title: "Happy Black Butler GIF By Funimation",
    url: "https://media2.giphy.com/media/Rek2a4M1MVzO4hMhl1/giphy.gif?cid=790b761168d553a3d3ce7951190555acf6683eed61cfb81b&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ['sebastian', 'black butler', 'characters', 'anime', 'cartoon'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 70,
    slug: "korean-korea-street-food-3ofSB1BswqflLVt4ic",
    title: "Street Food Korean GIF",
    url: "https://i.giphy.com/media/3ofSB1BswqflLVt4ic/giphy.webp",
    username: 'username2',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 71,
    slug: "korean-korea-street-food-l1AsEgyQki57Ipv8Y",
    title: "Street Food Korean GIF",
    url: "https://i.giphy.com/media/l1AsEgyQki57Ipv8Y/giphy.webp",
    username: 'username2',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 72,
    slug: "korean-korea-noodles-l1AsTtnAciIpMmLcI",
    title: "Noodles Ramen GIF By Korea",
    url: "https://i.giphy.com/media/l1AsTtnAciIpMmLcI/giphy.webp",
    username: 'username1',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 73,
    slug: "korean-korea-street-food-26mfgKWwjitX4hr8c",
    title: "Street Food GIF By Korea",
    url: "https://i.giphy.com/media/26mfgKWwjitX4hr8c/giphy.webp",
    username: 'username1',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 74,
    slug: "korean-korea-street-food-3ofSBwU8flPjspnOj6",
    title: "Street Food Korean GIF",
    url: "https://i.giphy.com/media/3ofSBwU8flPjspnOj6/giphy.webp",
    username: 'username2',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 75,
    slug: "korean-korea-meat-3ofSB7JJczmRaqS2NG",
    title: "Pork Belly Korean GIF",
    url: "https://i.giphy.com/media/3ofSB7JJczmRaqS2NG/giphy.webp",
    username: 'username2',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang', 'steak'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 76,
    slug: "korean-korea-meat-3ohuPpR1SJ11QXw6Ry",
    title: "Pork Belly Korean GIF",
    url: "https://i.giphy.com/media/3ohuPpR1SJ11QXw6Ry/giphy.webp",
    username: 'username2',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang', 'steak'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 77,
    slug: "korean-korea-meat-3ofSBxFGIqb9gsUGiY",
    title: "Pork Belly Korean GIF",
    url: "https://media2.giphy.com/media/3ofSBxFGIqb9gsUGiY/giphy.gif?cid=790b76110bc03a341bba94207d31a46abc35b56c04f1c55b&rid=giphy.gif&ct=g",
    username: 'username2',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang', 'steak'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 78,
    slug: "korean-korea-meat-l1AsPYngP4hg7QV8s",
    title: "Sizzling Pork Belly GIF",
    url: "https://i.giphy.com/media/l1AsPYngP4hg7QV8s/giphy.webp",
    username: 'username2',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang', 'steak'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 79,
    slug: "crabs-crabplace-thecrabplace-Ue5HMTOllCbsJTTHSs",
    title: "Seafood Shrimp GIF By The Crab Place",
    url: "https://i.giphy.com/media/Ue5HMTOllCbsJTTHSs/giphy.webp",
    username: 'username2',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 80,
    slug: "food-asian-foodporn-J1pdtFMOKiYqQ",
    title: "Asian Food Noodles GIF",
    url: "https://i.giphy.com/media/J1pdtFMOKiYqQ/giphy.webp",
    username: 'username2',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 81,
    slug: "ponyo-ramen-noodles-KVnBSCNwmKgiQ",
    title: "Ramen Noodles GIF",
    url: "https://i.giphy.com/media/KVnBSCNwmKgiQ/giphy.webp",
    username: 'username1',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 82,
    slug: "egg-melting-pasta-xctadCu8frm0g",
    title: "Noodles Melting GIF",
    url: "https://i.giphy.com/media/xctadCu8frm0g/giphy.webp",
    username: 'username1',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 83,
    slug: "8itapp-hungry-hangry-8it-TfumiIU3zb7K1zJoQD",
    title: "Hungry Food GIF By 8it",
    url: "https://i.giphy.com/media/TfumiIU3zb7K1zJoQD/giphy.webp",
    username: 'username2',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 84,
    slug: "spicy-tofu-szechuan-food-xT1R9yvTdWCFWw1sYg",
    title: "Mapo Tofu GIF",
    url: "https://media0.giphy.com/media/xT1R9yvTdWCFWw1sYg/giphy.gif?cid=790b761140fcf61158a2850f084f8b40b4c4c5988c68d7c7&rid=giphy.gif&ct=g",
    username: 'username2',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 85,
    slug: "spicy-tofu-szechuan-food-xT1R9LBT7wzX472kr6",
    title: "Mapo Tofu GIF",
    url: "https://media3.giphy.com/media/xT1R9LBT7wzX472kr6/giphy.gif?cid=790b7611545d0d01f0107962b3cffded0f278cf6f3bbfca9&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 86,
    slug: "spicy-tofu-szechuan-food-3o6nV5uAZ0qIUs7aq4",
    title: "Mapo Tofu GIF",
    url: "https://media0.giphy.com/media/3o6nV5uAZ0qIUs7aq4/giphy.gif?cid=790b7611020b23d9e3af3a0ac34f4caa52b9899aafabc823&rid=giphy.gif&ct=g",
    username: 'username2',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 87,
    slug: "spicy-szechuan-food-hot-26Ff6QFKhEzWagNna",
    title: "Szechuan Food GIF",
    url: "https://i.giphy.com/media/26Ff6QFKhEzWagNna/giphy.webp",
    username: 'username1',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 88,
    slug: "spicy-szechuan-food-hot-xT1R9JaB9IpMiGEZe8",
    title: "Szechuan Food GIF",
    url: "https://media2.giphy.com/media/xT1R9JaB9IpMiGEZe8/giphy.gif?cid=790b761184453021cfc20a884eddf3b2c62fa2d9fecbcf58&rid=giphy.gif&ct=g",
    username: 'username2',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 89,
    slug: "spicy-szechuan-food-hot-l4EpjCa5nNllWyrZu",
    title: "Szechuan Food GIF",
    url: "https://i.giphy.com/media/l4EpjCa5nNllWyrZu/giphy.webp",
    username: 'username2',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 90,
    slug: "spicy-chinese-food-hotpot-3o6nUZokCwQMHlSiLm",
    title: "Chinese Food Hotpot GIF",
    url: "https://i.giphy.com/media/3o6nUZokCwQMHlSiLm/giphy.webp",
    username: 'username2',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 91,
    slug: "spicy-hotpot-hot-pot-l4EoSQ9gwACp2WX5K",
    title: "Hot Pot GIF",
    url: "https://media2.giphy.com/media/l4EoSQ9gwACp2WX5K/giphy.gif?cid=790b7611a7702490d8b333148c90a8663c5f8b3fef096938&rid=giphy.gif&ct=g",
    username: 'username2',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 92,
    slug: "japanese-food-udon-3ohuAo6qZobKKp3mRq",
    title: "Yaki Udon Japanese GIF",
    url: "https://i.giphy.com/media/3ohuAo6qZobKKp3mRq/giphy.webp",
    username: 'username2',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 93,
    slug: "anime-gif-takoyaki-PHjbVPuzVbKyQ",
    title: "Anime Food Takoyaki GIF",
    url: "https://i.giphy.com/media/PHjbVPuzVbKyQ/giphy.webp",
    username: 'username2',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 94,
    slug: "tkwycom-mCwCPw7grgky3McNcO",
    title: "Ramen Takeaway GIF By Just Eat Takeaway.Com",
    url: "https://i.giphy.com/media/mCwCPw7grgky3McNcO/giphy.webp",
    username: 'username1',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 95,
    slug: "sushi-sushione-one-w6xNc3CNgerGW73DVE",
    title: "Sushi One GIF",
    url: "https://i.giphy.com/media/w6xNc3CNgerGW73DVE/giphy.webp",
    username: 'username2',
    tags: ['spicy noodles', 'foods', 'yummy', 'favorite', 'mukbang'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 96,
    slug: "hooters-hungry-wings-xUPGcJChjZr2wQPSiA",
    title: "Hungry Food Porn GIF By Hooters",
    url: "https://i.giphy.com/media/xUPGcJChjZr2wQPSiA/giphy.webp",
    username: 'username3',
    tags: ['chicken wings', 'foods', 'yummy', 'favorite'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 97,
    slug: "popeyeschicken-chicken-fried-biscuits-IeWbqFs6WX6IetZCKO",
    title: "Hungry Fried Chicken GIF By Popeyes Chicken",
    url: "https://i.giphy.com/media/IeWbqFs6WX6IetZCKO/giphy.webp",
    username: 'username3',
    tags: ['chicken wings', 'foods', 'yummy', 'favorite'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 98,
    slug: "sanders-colonel-kfc-indai-uWqlQcLQzWE7Kg3f8b",
    title: "Fried Chicken Dancing GIF By KFC India",
    url: "https://i.giphy.com/media/uWqlQcLQzWE7Kg3f8b/giphy.webp",
    username: 'username3',
    tags: ['chicken wings', 'foods', 'yummy', 'favorite'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 99,
    slug: "popeyeschicken-chicken-fried-biscuits-U6vmfzSQTDAEiewKzK",
    title: "Hungry Fried Chicken GIF By Popeyes Chicken",
    url: "https://i.giphy.com/media/U6vmfzSQTDAEiewKzK/giphy.webp",
    username: 'username3',
    tags: ['chicken wings', 'foods', 'yummy', 'favorite'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 100,
    slug: "popeyeschicken-chicken-fried-biscuits-jqwk5Jxh8UcbMZbxK7",
    title: "Hungry Fried Chicken GIF By Popeyes Chicken",
    url: "https://media1.giphy.com/media/jqwk5Jxh8UcbMZbxK7/giphy.gif?cid=790b7611fe50397d30579671a4c0743e833c05c8f747c1cc&rid=giphy.gif&ct=g",
    username: 'username3',
    tags: ['chicken wings', 'foods', 'yummy', 'favorite'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 101,
    slug: "al-nowair-chicken-fried-strips-QubjOLVGV6Uqw6WqiO",
    title: "Fried Chicken Eating GIF By Alnowair",
    url: "https://i.giphy.com/media/QubjOLVGV6Uqw6WqiO/giphy.webp",
    username: 'username3',
    tags: ['chicken wings', 'foods', 'yummy', 'favorite'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 102,
    slug: "popeyeschicken-chicken-fried-biscuits-XblnnkERdx9atT6Gi3",
    title: "Hungry Fried Chicken GIF By Popeyes Chicken",
    url: "https://media3.giphy.com/media/XblnnkERdx9atT6Gi3/giphy.gif?cid=790b761150a9abf2c352369e93710cc7ef9156f959e54db4&rid=giphy.gif&ct=g",
    username: 'username3',
    tags: ['chicken wings', 'foods', 'yummy', 'favorite'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 103,
    slug: "DefyTVNetwork-duck-dynasty-defytv-1Cx37MhBlegaFcDK6Y",
    title: "Duck Dynasty GIF By DefyTV",
    url: "https://i.giphy.com/media/1Cx37MhBlegaFcDK6Y/giphy.webp",
    username: 'username3',
    tags: ['chicken wings', 'foods', 'yummy', 'favorite'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 104,
    slug: "iFHLabs-food-delicious-zy9wp81bCIyzu",
    title: "Filet Mignon Food GIF By FleishmanHillard",
    url: "https://i.giphy.com/media/zy9wp81bCIyzu/giphy.webp",
    username: 'username3',
    tags: ['chicken wings', 'foods', 'yummy', 'favorite'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 105,
    slug: "gLBMrYhpYrGdG",
    title: "Filet Mignon Steak GIF",
    url: "https://i.imgur.com/nXpJnEY.gif",
    username: 'username3',
    tags: ['foods', 'yummy', 'favorite', 'steak'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 106,
    slug: "machine-recipe-steak-46tlenRBlqhl6",
    title: "Machine Reverse GIF",
    url: "https://i.giphy.com/media/46tlenRBlqhl6/giphy.webp",
    username: 'username3',
    tags: ['foods', 'yummy', 'favorite', 'steak'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 107,
    slug: "itssuppertime-viceland-cooking-3oFzm3EbWuLElALSDe",
    title: "Recipes Cooking GIF By It's Suppertime",
    url: "https://media3.giphy.com/media/3oFzm3EbWuLElALSDe/giphy.gif?cid=790b761169451456c6cb25797d5bac7e479e6827a2c440fa&rid=giphy.gif&ct=g",
    username: 'username3',
    tags: ['foods', 'yummy', 'favorite', 'steak'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 108,
    slug: "iFHLabs-steakhouse-longhorn-Y1OK9MzAp4IQ8",
    title: "Longhorn Steakhouse GIF",
    url: "https://i.giphy.com/media/Y1OK9MzAp4IQ8/giphy.webp",
    username: 'username3',
    tags: ['foods', 'yummy', 'favorite', 'steak'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 109,
    slug: "food-curry-128EO9DYdoIjMk",
    title: "Curry Steak GIF",
    url: "https://i.giphy.com/media/eN3ifAMjwpyC0Ezsz7/giphy.webp",
    username: 'username3',
    tags: ['foods', 'yummy', 'favorite', 'steak'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 110,
    slug: "grill-aHDLXmYz7OqgU",
    title: "Grill GIF",
    url: "https://media2.giphy.com/media/aHDLXmYz7OqgU/giphy.gif?cid=790b7611c29fe3a9a659ee93ad7d5e8846103b906ff6915e&rid=giphy.gif&ct=g",
    username: 'username3',
    tags: ['foods', 'yummy', 'favorite', 'steak'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 111,
    slug: "outbacksteakhouse-dinner-outback-steakhouse-fnEo2JUDMa6Piq",
    title: "Dinner Steak GIF By Outback Steakhouse",
    url: "https://media2.giphy.com/media/fnEo2JUDMa6PiqZN84/giphy.gif?cid=790b76114a873d73c6510faa73c1306d1f6da0fac0d0fecc&rid=giphy.gif&ct=g",
    username: 'username3',
    tags: ['foods', 'yummy', 'favorite', 'steak'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 112,
    slug: "beeffordinner-technique-beef-juicy-gw3NpMPvrN64YrC0",
    title: "Meat Steak GIF By Beef. It's What's For Dinner.",
    url: "https://i.giphy.com/media/gw3NpMPvrN64YrC0/giphy.webp",
    username: 'username3',
    tags: ['foods', 'yummy', 'favorite', 'steak'],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 113,
    slug: "husky-sneezes-JpKv5m3OfJRtu",
    title: "Husky GIF",
    url: "https://media1.giphy.com/media/JpKv5m3OfJRtu/giphy.gif?cid=790b7611419edb7a311f8070d47f13f707457de2870bea01&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ["others", "animal", "dog"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 114,
    slug: "gonetothesnowdogs-sleep-nap-time",
    title: "Tired Siberian Husky GIF By Gone To The Snow Dogs",
    url: "https://i.giphy.com/media/BMJflM7fpWFrTeHXzm/giphy.webp",
    username: 'username1',
    tags: ["others", "animal", "dog"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 115,
    slug: "gonetothesnowdogs-snow-dogs-gone-to-the-gttsd-ork",
    title: "Happy Best Day Ever GIF By Gone To The Snow Dogs",
    url: "https://i.giphy.com/media/ork2E1TWj802SBFHUy/giphy.webp",
    username: 'username1',
    tags: ["others", "animal", "dog"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 116,
    slug: "tiktok-aww-YrHHwUPaDarl6mELwA",
    title: "Aww Yes GIF By TikTok",
    url: "https://i.giphy.com/media/YrHHwUPaDarl6mELwA/giphy.webp",
    username: 'username1',
    tags: ["others", "animal", "dog"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 117,
    slug: "TikTokFrance-dog-husky-chien",
    title: "Dog Chien GIF By TikTok Franc",
    url: "https://i.giphy.com/media/J19Lf3siZKdJ87fV4V/giphy.webp",
    username: 'username1',
    tags: ["others", "animal", "dog"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 118,
    slug: "SWR-Kindernetz-snow-winter-husky-709tyPFmEgWt5W5UPX",
    title: "Dog Snow GIF By SWR Kindernetz",
    url: "https://media1.giphy.com/media/709tyPFmEgWt5W5UPX/giphy.gif?cid=790b7611994b72a181df85f7013b2d915faed6647eb56828&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ["others", "animal", "dog"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 119,
    slug: "tiktok-on-my-way-omw-tiktok-animals-cImxFRmPTQx5I7HU8l",
    title: "On My Way Running GIF By TikTok",
    url: "https://i.giphy.com/media/cImxFRmPTQx5I7HU8l/giphy.webp",
    username: 'username1',
    tags: ["others", "animal", "dog"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 120,
    slug: "cute-puppy-d5x4HPXPNqsms",
    title: "Puppy Howl GIF",
    url: "https://i.giphy.com/media/d5x4HPXPNqsms/giphy.webp",
    username: 'username1',
    tags: ["others", "animal", "dog"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 121,
    slug: "bbcamerica-penguins-bbc-america-dynasties-1mikWsbdZMtfAS2sHR",
    title: "Happy Baby Penguin GIF By BBC America",
    url: "https://i.giphy.com/media/1mikWsbdZMtfAS2sHR/giphy.webp",
    username: 'username1',
    tags: ["others", "animal", "dog", "seals"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 122,
    slug: "baby-seals-imgs-8rchd4maYAjZe",
    title: "Baby Seals GIF",
    url: "https://media1.giphy.com/media/8rchd4maYAjZe/giphy.gif?cid=790b76110f1217152ae349ffb5d13f22871654d7372b8945&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ["others", "animal", "dog", "seals"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 123,
    slug: "zooberlin-SYuLn9yAeQg8bHyQSp",
    title: "Sun Chill GIF By Zoo Berlin",
    url: "https://i.giphy.com/media/SYuLn9yAeQg8bHyQSp/giphy.webp",
    username: 'username1',
    tags: ["others", "animal", "dog", "seals"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 124,
    slug: "pbsnature-baby-seal-Uo5ZtFtn6p5BzLCWJj",
    title: "Rolling Pbs Nature GIF By Nature On PBS",
    url: "https://i.giphy.com/media/Uo5ZtFtn6p5BzLCWJj/giphy.webp",
    username: 'username1',
    tags: ["others", "animal", "dog", "seals"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 125,
    slug: "seal-adM1FEGALvsLS",
    title: "Seal GIF",
    url: "https://i.giphy.com/media/adM1FEGALvsLS/giphy.webp",
    username: 'username1',
    tags: ["others", "animal", "dog", "seals"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 126,
    slug: "seal-CP6IT36umk7Zu",
    title: "Seal GIF",
    url: "https://i.giphy.com/media/CP6IT36umk7Zu/giphy.webp",
    username: 'username1',
    tags: ["others", "animal", "dog", "seals"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 127,
    slug: "bbcearth-cute-otter",
    title: "Otter GIF By BBC Earth",
    url: "https://media0.giphy.com/media/l1K9DZ3sYRSvaR1wA/giphy.gif?cid=ecf05e474iv1f0m01ng4sjadpmr0y07zq8ij0tqh2xej4m77&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ["others", "animal", "dog", "seals"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 128,
    slug: "cute-white-s0k30jjI04THq",
    title: "Blinking Baby Animals GIF",
    url: "https://i.giphy.com/media/s0k30jjI04THq/giphy.webp",
    username: 'username1',
    tags: ["others", "animal", "dog", "seals"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 129,
    slug: "baby-seals-1VI11KXvGKZ8c",
    title: "Baby Seals GIF",
    url: "https://i.giphy.com/media/1VI11KXvGKZ8c/giphy.webp",
    username: 'username1',
    tags: ["others", "animal", "dog", "seals"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 130,
    slug: "pbsnature-baby-seal-nZUcRJ4axegy4JghGU",
    title: "Rolling Pbs Nature GIF By Nature On PBS",
    url: "https://media2.giphy.com/media/nZUcRJ4axegy4JghGU/giphy.gif?cid=790b76112e94e45fdcb3e12639739ec01bb8ed9129738f65&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ["others", "animal", "dog", "seals"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 131,
    slug: "seal-9Uy6vlCFdb7X14t2ce",
    title: "Pbs Nature Swimming GIF By Nature On PBS",
    url: "https://media0.giphy.com/media/9Uy6vlCFdb7X14t2ce/giphy.gif?cid=790b7611e9eddf6d68a4265b84b11c5010363de90b16dea0&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ["others", "animal", "dog", "seals"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 132,
    slug: "pbsnature-baby-seal-LKMRVrRYVPtizgXGPP",
    title: "Rolling Pbs Nature GIF By Nature On PBS",
    url: "https://media4.giphy.com/media/LKMRVrRYVPtizgXGPP/giphy.gif?cid=790b7611a52351caae1274aa74f5999c34f83596b7a6197b&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ["others", "animal", "dog", "seals"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 133,
    slug: "bbcamerica-nature-bbc-america-animal-babies-KqkWbMzKU6KVoArppK",
    title: "Baby Seal GIF By BBC America",
    url: "https://i.giphy.com/media/KqkWbMzKU6KVoArppK/giphy.webp",
    username: 'username1',
    tags: ["others", "animal", "dog", "seals"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 134,
    slug: "georgiaaquarium-RIfyNBJHyVTEm5i1lQ",
    title: "GIF By Georgia Aquarium",
    url: "https://media1.giphy.com/media/RIfyNBJHyVTEm5i1lQ/giphy.gif?cid=790b76111020c91f26c6a36eafbe22f796000e036bcfb07b&rid=giphy.gif&ct=g",
    username: 'username1',
    tags: ["others", "animal", "dog", "seals"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
  {
    id: 135,
    slug: "pbsnature-cute-animals-seal-EQkSAkKMGm3lw1zB59",
    title: "Antarctica GIF By BBC America",
    url: "https://i.giphy.com/media/kgHt4LhS87OFR9qFao/giphy.webp",
    username: 'username1',
    tags: ["others", "animal", "dog", "seals"],
    createdAt: Date.now(),
    lastUpdated: Date.now(),
    rating: 9.6
  },
];

export { users, gifs, tags };
