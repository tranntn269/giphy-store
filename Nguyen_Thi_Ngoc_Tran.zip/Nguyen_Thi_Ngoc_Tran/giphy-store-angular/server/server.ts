import { gifs } from 'server/data';
import { Gif } from './../src/app/modules/features/main/models/gif.model';
import { User } from './../src/app/modules/features/main/models';

import { Request, Response, NextFunction } from 'express';


const jsonServer = require('json-server');

// create json server and its router first
const server = jsonServer.create();
const router = jsonServer.router('server/db.json');
const middlewares = jsonServer.defaults({
  bodyParser: true,
  readOnly: false,
});
const db = require('./db.json');
const fs = require('fs');

server.use(middlewares);

// uncomment for testing loading spinner
server.use(function (req: Request, res: Response, next: NextFunction) {
  setTimeout(next, 200);
});

//custom route
server.get('/gif', (req: Request, res: Response) => {

  let slug = req.query['slug'];
  if (slug != null && slug !== '') {
    let result = db.gifs.find((gif: Gif) => {
      return gif.slug === slug;
    })

    if (result) {
      res.status(200).jsonp(result);
    } else {
      res.status(400).jsonp({
        error: `Can not find gif with slug ${slug}`
      });
    }

  } else {
    res.status(400).jsonp({
      error: "Invalid slug"
    });
  }
});

server.get('/gifs/favourite', (req: Request, res: Response) => {
  const users = readUsers();
  let user = users.find((u: User) => u.token === req.headers.authorization);

  if (user === undefined || user === null) {
    res.status(400).send('User does not exisst');

  }
  else {
    let favoriteLists = [];

    if (user.favorites && user.favorites.length > 0) {
      const favoriteList = user.favorites;
      let gifLists = db.gifs;

      for (let i = 0; i < favoriteList.length; i++) {
        const gifIndex = gifLists.findIndex((gif: Gif) => gif.id === favoriteList[i]);

        if (gifIndex !== -1) {
          favoriteLists.push(gifLists[gifIndex]);
        }
      }
    }

    res.status(200).jsonp(favoriteLists);
  }
});

server.get('/gifs/posted', (req: Request, res: Response) => {
  const users = readUsers();
  let user = users.find((u: User) => u.token === req.headers.authorization);

  if (user === undefined || user === null) {
    res.status(400).send('User does not exisst');

  }
  else {
    let postedLists = [];

    let gifLists = db.gifs;

    for (let i = 0; i < gifLists.length; i++) {
      if (gifLists[i].username === user.username) {
        postedLists.push(gifLists[i]);
      }
    }
    res.status(200).jsonp(postedLists);
  }
});

server.get('/user', (req: Request, res: Response) => {
  const users = readUsers();
  let user = users.find((u: User) => u.token === req.headers.authorization);

  if (user === undefined || user === null) {

    res.status(400).send('User does not exisst');

  }
  else {
    res.status(200).jsonp(user);
  }

});

server.patch('/user', (req: Request, res: Response) => {
  const users = readUsers();
  let user = users.find((u: User) => u.token === req.headers.authorization);

  if (user === undefined || user === null) {

    res.status(500).send('User does not exist');

  } else if (req.body.gifId) {
    if (!user.favorites) user.favorites = [];

    const favourIdex = user.favorites.indexOf(req.body.gifId);

    if (favourIdex !== -1) {
      user.favorites.splice(favourIdex, 1);
    }
    else {
      user.favorites.push(req.body.gifId);
    }

    const index = users.findIndex((u: User) => u.token === req.headers.authorization);
    db.users[index] = user;
    const updatedData = JSON.stringify(db);
    fs.writeFileSync("./server/db.json", updatedData);

    res.send({
      user
    });
    router.db.setState(JSON.parse(updatedData));

  } else {
    res.status(400).send('Bad request');
  }
})

server.post('/gifs', (req: Request, res: Response) => {
  const users = readUsers();
  let user = users.find((u: User) => u.token === req.headers.authorization);

  if (user === undefined || user === null) {

    res.status(500).send('User does not exist');

  } else if (req.body) {

    const error = validateGif(req.body);

    if (error) {

      res.status(400).send(error);

    } else {
      req.body.id = db.gifs.length + 1;
      req.body.username = user.username;
      req.body.slug = createSlug(req.body.title);
      req.body.createdAt = Date.now();
      req.body.lastUpdated = Date.now();

      const { id, slug, title, imgBase64, username, tags, createdAt, lastUpdated } = req.body;
      const requestObj = { id, slug, title, imgBase64, username, tags, createdAt, lastUpdated };

      db.gifs.push({ ...requestObj });
      //reverse gif
      db.gifs.reverse();
      const updatedData = JSON.stringify(db);
      fs.writeFileSync("./server/db.json", updatedData);

      res.send(
        { ...requestObj }
      );
      router.db.setState(JSON.parse(updatedData));
    }
  } else {
    res.status(400).send('Bad request');
  }
});

server.post('/login', (req: Request, res: Response, next: NextFunction) => {
  const users = readUsers();
  const user = users.find(
    (u: User) => u.username === req.body?.username && u.password === req.body?.password
  );

  if (user) {
    const userIndex = users.findIndex((u: User) => u.username === req.body.username);
    const newAccessToken = checkIfAdmin(req.body);

    db.users[userIndex] = { ...user, token: newAccessToken };
    const updatedData = JSON.stringify(db);
    fs.writeFileSync("./server/db.json", updatedData);

    res.send({ ...formatUser(user), token: newAccessToken });

    router.db.setState(JSON.parse(updatedData));
  } else {
    res.status(401).send('Incorrect username or password');
  }
});


server.post('/register', (req: Request, res: Response) => {
  const users = readUsers();
  const user = users.find((u: User) => u.username === req.body?.username);

  if (user === undefined || user === null) {
    const newAccessToken = checkIfAdmin(req.body);

    db.users.push({ ...req.body, token: newAccessToken });

    const updatedData = JSON.stringify(db);

    fs.writeFileSync("./server/db.json", updatedData);

    res.send({
      ...formatUser(req.body),
      token: newAccessToken
    });

    router.db.setState(JSON.parse(updatedData));

  } else {
    res.status(500).send('User already exists');
  }
});

server.use('/users', (req: Request, res: Response, next: NextFunction) => {
  checkAuthorized(req, res, next);
});

server.use('/user', (req: Request, res: Response, next: NextFunction) => {
  checkAuthorized(req, res, next);
});


// Use default router
server.use(router);

server.use((req: Request, res: Response, next: NextFunction) => {
  if (req.method === 'POST') {
    req.body.createdAt = Date.now();
    req.body.lastUpdated = Date.now();
  } else if (req.method === 'PATCH' || req.method === 'PUT') {
    req.body.lastUpdated = Date.now();
  }
  // Continue to JSON Server router
  next()
})

// Start server
const port = 3000;
server.listen(port, () => {
  console.log(`JSON Server is running on port ${port}`);
});

function readUsers() {
  const dbRaw = fs.readFileSync('./server/db.json');
  const users = JSON.parse(dbRaw).users;
  return users;
}

function formatUser(user: User) {
  if (!user) {
    return;
  }

  delete user.password;
  user.role = user.username === 'admin'
    ? 'admin'
    : 'user';
  return user;
}

function checkIfAdmin(user: User, bypassToken = false) {
  return user?.username === 'admin' || bypassToken === true
    ? 'admin-token'
    : getUniqueId(2);
}

function isAuthorized(req: Request) {
  return req.headers.authorization ? true :
    false;
}


function checkAuthorized(req: Request, res: Response, next: NextFunction) {
  if (isAuthorized(req) || req.query['bypassAuth'] === 'true') {
    next();
  } else {
    res.sendStatus(401);
  }
}

function getUniqueId(parts: number): string {
  const stringArr = [];
  for (let i = 0; i < parts; i++) {
    const S4 = (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    stringArr.push(S4);
  }
  return stringArr.join('-');
}

function validateGif(gif: Gif) {
  if (!gif.title) return "Title is required.";
  if (!gif.tags || gif.tags.length === 0) return 'Must contain at least 1 tag name';
  if (!gif.imgBase64) return "Gif file is missing...";
  return "";
}

function createSlug(value: string) {
  return value
    .replace(/[^a-z0-9_]+/gi, "-")
    .replace(/^-|-$/g, "")
    .toLowerCase();
}
