import { ROUTE } from './modules/shared/constants/route';
import { RegisterComponent } from './modules/core/components/register/register.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PageNotFoundComponent } from './modules/core/components/page-not-found/page-not-found.component';
import { LoginComponent } from './modules/core/components/login/login.component';
import { AuthGuard } from './modules/core/auth';

const routes: Routes = [
  {
    path: ROUTE.ADMIN,
    loadChildren: () => import('./modules/features/admin/admin.module').then(m => m.AdminModule)
  },
  {
    path: ROUTE.MAIN,
    loadChildren: () => import('./modules/features/main/main.module').then(m => m.MainModule),
  },
  {
    path: ROUTE.AUTH,
    children:
      [
        { path: ROUTE.LOGIN, component: LoginComponent },
        { path: ROUTE.REGISTER, component: RegisterComponent }

      ]
  },
  {
    path: '',
    redirectTo: ROUTE.MAIN,
    pathMatch: 'full',
  },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
