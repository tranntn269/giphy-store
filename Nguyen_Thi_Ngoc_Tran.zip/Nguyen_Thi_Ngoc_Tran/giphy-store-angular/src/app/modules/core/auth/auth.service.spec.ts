import { User } from './../../features/main/models/user.model';
import { AuthService } from 'src/app/modules/core/auth/auth.service';
import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';


describe('AuthService', () => {
  let httpTestingController: HttpTestingController;
  let service: AuthService;
  let router: Router;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule.withRoutes([]),],
    });

    service = TestBed.inject(AuthService);
    router = TestBed.inject(Router)
    httpTestingController = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it(
    'should perform login correctly',
    (done) => {
      // Set up
      const expectedData: User[] = [{
        "username": "username1",
        "token": "1e39-6ccc",
        "role": "user"
      }]

      let username = "username1";
      let password = "123";

      service.login({ username, password }).subscribe(
        (data: any) => {
          expect(data).toEqual(expectedData);
          done();
        },
      );

      const testRequest = httpTestingController.expectOne('http://localhost:3000/login');

      testRequest.flush(expectedData);
    }
  )
});
