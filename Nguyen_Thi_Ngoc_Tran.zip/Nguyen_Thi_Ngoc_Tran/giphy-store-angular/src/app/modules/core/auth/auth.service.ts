import { ROUTE } from './../../shared/constants/route';
import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";
import { User } from "../../features/main/models";
import { Authenticate } from "./auth.model";
import { tap } from "rxjs";
import { Router } from "@angular/router";

@Injectable({
  providedIn: 'root'
})

export class AuthService {
  private _user = localStorage.getItem('user');
  private userSubject$ = new BehaviorSubject<User | null>(this._user as User | null);
  user$ = this.userSubject$.asObservable();

  constructor(
    private httpClient: HttpClient,
    private router: Router,
  ) {
    const user = localStorage.getItem('user');
    if (user) {
      this.userSubject$.next(JSON.parse(user));
    }
  }

  login(authenticate: Authenticate): Observable<User> {
    return this.httpClient.post<User>('http://localhost:3000/login', authenticate).pipe(
      tap((user: User) => {
        localStorage.setItem('user', JSON.stringify(user));
        localStorage.setItem('token', JSON.stringify(user.token));
        this.userSubject$.next(user);
      }),
    );
  }

  logout() {
    this.userSubject$.next(null);
    localStorage.removeItem("user");
    this.router.navigate([`${ROUTE.AUTH}/${ROUTE.LOGIN}`]);
  }

  register(authenticate: Authenticate): Observable<User> {
    return this.httpClient.post<User>('http://localhost:3000/register', authenticate).pipe(
      tap((user: User) => {
        localStorage.setItem('user', JSON.stringify(user));
        localStorage.setItem('token', JSON.stringify(user.token));
        this.userSubject$.next(user);

      }),
    );
  }

  updateUserInfo(user: User) {
    localStorage.setItem('user', JSON.stringify(user));
    this.userSubject$.next(user);
  }


}
