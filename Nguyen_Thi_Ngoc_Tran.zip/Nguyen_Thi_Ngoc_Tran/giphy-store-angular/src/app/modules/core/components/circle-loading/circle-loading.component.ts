import { LoadingService } from './../../sevices/loading.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'circle-loading',
  templateUrl: './circle-loading.component.html',
  styleUrls: ['./circle-loading.component.scss']
})
export class CircleLoadingComponent implements OnInit {

  constructor(
    public loadingService: LoadingService
  ) { }

  ngOnInit(): void {
  }

}
