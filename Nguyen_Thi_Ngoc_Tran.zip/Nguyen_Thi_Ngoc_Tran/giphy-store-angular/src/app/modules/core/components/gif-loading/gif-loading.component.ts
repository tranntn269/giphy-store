import { Component, OnInit } from '@angular/core';
import { LoadingService } from '../../sevices/loading.service';

@Component({
  selector: 'app-gif-loading',
  templateUrl: './gif-loading.component.html',
  styleUrls: ['./gif-loading.component.scss']
})
export class GifLoadingComponent implements OnInit {
  items = [
    140, 190, 170, 120, 160, 180, 140, 150, 170, 170, 140, 190, 170, 120, 160, 180, 140, 150, 170, 170
  ]
  constructor(
    public loadingService: LoadingService
  ) { }

  ngOnInit(): void {
  }

}
