import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'horizon-loading',
  templateUrl: './horizon-loading.component.html',
  styleUrls: ['./horizon-loading.component.scss']
})
export class HorizonLoadingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
