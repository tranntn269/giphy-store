import { LoadingService } from './../../sevices/loading.service';
import { ROUTE } from './../../../shared/constants/route';
import { MessageService } from './../messages/messages.service';
import { COLOURS, PAGINATION } from 'src/app/modules/shared/constants';
import { ChangeDetectionStrategy, Component, OnInit, AfterViewInit, Output, EventEmitter, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BehaviorSubject, catchError, Subscription, throwError, finalize } from 'rxjs';
import { tap } from 'rxjs';
import { AuthService } from '../../auth/auth.service';
import { Authenticate } from '../../auth/auth.model';
import { Router } from '@angular/router';
import { GifService } from 'src/app/modules/features/main/services/gifs.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  providers: [MessageService, LoadingService],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class LoginComponent implements OnInit, AfterViewInit, OnDestroy {
  subscriptions: Subscription[] = [];
  colours = COLOURS;
  logInForm: FormGroup;
  validateForm$ = new BehaviorSubject<boolean>(false);
  @Output() submitForm = new EventEmitter<Authenticate>();

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private messagesService: MessageService,
    private gifService: GifService,
    private loadingService: LoadingService
  ) { }


  ngAfterViewInit(): void {
  }


  ngOnInit(): void {
    this.initForm();
  }

  initForm() {
    this.logInForm = this.fb.group({
      username: ['',
        Validators.compose([
          Validators.required,
          Validators.minLength(5),
          Validators.pattern(/^[a-zA-Z0-9]+$/),
        ]),],
      password: ['', Validators.compose(
        [
          Validators.required,
          // Validators.minLength(6),
          // Validators.pattern(/^(?=.*[!@#$%^&*]+)[a-z0-9!@#$%^&*]{6,32}$/)
        ]
      )]
    })
  }

  closeDialog() {
  }

  logIn() {
    this.validateForm$.next(true);

    if (this.logInForm.status == 'VALID') {
      this.loadingService.showLoading();
      const request: Authenticate = {
        username: this.logInForm.value.username,
        password: this.logInForm.value.password
      }
      const subscription$ = this.authService.login(request).pipe(
        finalize(() => this.loadingService.hideLoading()),
        tap(_ => {
          this.gifService.updatePaginationSubject({
            pageIndex: PAGINATION.PAGEINDEX,
            pageSize: PAGINATION.PAGESIZE,
          })
          this.router.navigate([`/${ROUTE.MAIN}`])
        }),
        catchError(err => {
          const message = "Account does not exist";
          this.messagesService.showErrors(message);
          return throwError(err);
        })
      ).subscribe();

      this.subscriptions.push(subscription$)
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }


}
