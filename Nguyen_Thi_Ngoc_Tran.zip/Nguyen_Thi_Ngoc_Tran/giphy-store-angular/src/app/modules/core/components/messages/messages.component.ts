import { COLOURS } from 'src/app/modules/shared/constants';
import { Component, OnInit } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { MessageService } from './messages.service';

@Component({
  selector: 'messages',
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.scss']
})
export class MessagesComponent implements OnInit {
  colours = COLOURS;
  showMessages = false;

  errors$: Observable<string[]>;

  constructor(public messagesService: MessageService) {
  }

  onClose() {
    this.showMessages = false;
  }

  ngOnInit(): void {
    this.errors$ = this.messagesService.errors$.pipe(
      tap(() => this.showMessages = true)
    );
  }

}
