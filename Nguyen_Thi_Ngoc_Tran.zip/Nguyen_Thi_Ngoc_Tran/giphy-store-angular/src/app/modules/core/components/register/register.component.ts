import { LoadingService } from './../../sevices/loading.service';
import { ROUTE } from './../../../shared/constants/route';
import { MessageService } from './../messages/messages.service';
import { catchError, tap, throwError, Subscription, finalize } from 'rxjs';
import { AuthService } from 'src/app/modules/core/auth/auth.service';

import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Authenticate } from '../../auth/auth.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss', '../login/login.component.scss'],
  providers: [MessageService, LoadingService]
})

export class RegisterComponent implements OnInit, OnDestroy {
  signInForm: FormGroup;
  subscriptions: Subscription[] = []

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private messagesService: MessageService,
    private loadingService: LoadingService
  ) { }


  ngOnInit(): void {
    this.initForm();
  }

  initForm() {
    const PASSWORD_PATTERN = /^(?=.*[!@#$%^&*]+)[a-z0-9!@#$%^&*]{6,32}$/;

    this.signInForm = this.fb.group({
      username: [
        '',
        Validators.compose([
          Validators.required,
          Validators.minLength(5),
          Validators.pattern(/^[a-zA-Z0-9]+$/),
        ]),
      ],
      password: [
        '',
        Validators.compose([
          Validators.required,
          Validators.minLength(6),
          // Validators.pattern(PASSWORD_PATTERN),
        ]),
      ],
      // confirmPassword: [
      //   '',
      //   Validators.compose([
      //     Validators.required,
      //     Validators.minLength(6),
      //     // Validators.pattern(PASSWORD_PATTERN),
      //   ]),
      // ],
    });
  }

  register() {
    this.loadingService.showLoading();
    const request: Authenticate = {
      username: this.signInForm.value.username,
      password: this.signInForm.value.password
    }
    const subscription$ = this.authService.register(request).pipe(
      finalize(() => this.loadingService.hideLoading()),
      tap(_ => this.router.navigate([`/${ROUTE.MAIN}`])),
      catchError(err => {
        this.messagesService.showErrors(err.error);
        return throwError(err.error);
      })
    ).subscribe();
    this.subscriptions.push(subscription$);
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }

}
