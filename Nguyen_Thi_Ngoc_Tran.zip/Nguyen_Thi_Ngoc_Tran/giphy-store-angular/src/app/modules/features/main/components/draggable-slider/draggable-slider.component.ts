import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-draggable-slider',
  templateUrl: './draggable-slider.component.html',
  styleUrls: ['./draggable-slider.component.scss']
})
export class DraggableSliderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
