import { COLOURS } from 'src/app/modules/shared/constants';
import { Component, Input, OnInit } from '@angular/core';

interface Item {
  title: string;
  url: string;
}

@Component({
  selector: 'empty-gif',
  templateUrl: './empty-gif.component.html',
  styleUrls: ['./empty-gif.component.scss']
})

export class EmptyGifComponent implements OnInit {
  colours = COLOURS;
  @Input() item: Item;

  constructor() { }

  ngOnInit(): void {
  }

}
