import { Router } from '@angular/router';
import { ChangeDetectionStrategy, Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { COLOURS, PAGINATION } from 'src/app/modules/shared/constants';
import { Tag } from '../../models';
import { GifService } from '../../services/gifs.service';

@Component({
  selector: 'explore-tag',
  templateUrl: './explore-tag.component.html',
  styleUrls: ['./explore-tag.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class ExploreTagComponent implements OnInit {
  colours = COLOURS;
  @ViewChild('tag') tagEl: ElementRef;
  @Input() items: Tag[];

  constructor(
    private gifService: GifService,
    private router: Router,

  ) { }

  ngOnInit(): void {
  }

  exploreTags() {
    if (!this.tagEl.nativeElement.classList.contains('tag--multiline')) {
      this.tagEl.nativeElement.classList.add('tag--multiline');
    }
    else this.tagEl.nativeElement.classList.remove('tag--multiline');
  }

  updateSearch(searchWord: string) {
    this.gifService.updatePaginationSubject({
      pageIndex: PAGINATION.PAGEINDEX,
      pageSize: PAGINATION.PAGESIZE,
    })
    this.gifService.updateSearchStringSubject('#' + searchWord);
  }

}
