import { ROUTE } from './../../../../shared/constants/route';
import { TranslateService } from '@ngx-translate/core';
import { LoadingService } from './../../../../core/sevices/loading.service';
import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { FavoriteGifService } from '../../services/favorite-gif.service';
import { finalize } from 'rxjs';

@Component({
  selector: 'favorite-gif-list',
  templateUrl: './favorite-gif-list.component.html',
  styleUrls: ['./favorite-gif-list.component.scss'],
  providers: [LoadingService],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class FavoriteGifListComponent implements OnInit {
  gifs$ = this.favoriteService.favoriteGifList$.pipe(
    finalize(() => this.loadingService.hideLoading())
  );

  emptyPage = {
    title: this.translateService.instant('empty-gif.see-all-gifs'),
    url: `${ROUTE.MAIN}/${ROUTE.COLLECTION}`
  }

  constructor(
    public favoriteService: FavoriteGifService,
    private loadingService: LoadingService,
    private translateService: TranslateService
  ) { }

  ngOnInit(): void {
    this.loadingService.showLoading();
  }


}
