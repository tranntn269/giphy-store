import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

interface IFooter {
  title: string;
  navList: string[]
}

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class FooterComponent implements OnInit {
  readonly iconPath = 'assets/imgs/icons/social-icon.svg';

  footer: IFooter[] = [
    {
      title: this.translateService.instant('footer.product'),
      navList: [
        this.translateService.instant('footer.pricing'),
        this.translateService.instant('footer.login'),
        this.translateService.instant('footer.free-trial')
      ]
    },

    {
      title: this.translateService.instant('footer.solutions'),
      navList: [
        this.translateService.instant('footer.success-stories'),
        this.translateService.instant('footer.manufacturing'),
        this.translateService.instant('footer.banking'),
        this.translateService.instant('footer.retail'),
      ]
    },

    {
      title: this.translateService.instant('footer.engine-help'),
      navList: [
        this.translateService.instant('footer.sales-teams'),
        this.translateService.instant('footer.analysts'),
        this.translateService.instant('footer.software-enginners'),
        this.translateService.instant('footer.data-scientists'),
      ]
    },
    {
      title: this.translateService.instant('footer.company'),
      navList: [
        this.translateService.instant('footer.new-updates'),
        this.translateService.instant('footer.about-us'),
        this.translateService.instant('footer.privacy-terms'),
        this.translateService.instant('footer.careers'),
        this.translateService.instant('footer.contact-us'),
      ]
    }
  ];

  icons: string[] = [
    'facebook',
    'youtube',
    'twitter',
    'pinterest',
    'instagram'
  ]

  constructor(private translateService: TranslateService) { }

  ngOnInit(): void {
  }

}
