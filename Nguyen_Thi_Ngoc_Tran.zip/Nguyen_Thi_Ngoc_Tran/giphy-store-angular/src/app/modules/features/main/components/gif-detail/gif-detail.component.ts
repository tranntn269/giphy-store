import { LoadingService } from './../../../../core/sevices/loading.service';
import { AuthService } from 'src/app/modules/core/auth/auth.service';
import { catchError, finalize, map, merge, Observable, tap } from 'rxjs';
import { GiftDetailService } from './../../services/gif-detail.service';
import { COLOURS } from 'src/app/modules/shared/constants';
import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Gif } from '../../models';
import { MessageService } from 'src/app/modules/core/components/messages/messages.service';

@Component({
  selector: 'app-gif-detail',
  templateUrl: './gif-detail.component.html',
  styleUrls: ['./gif-detail.component.scss'],
  providers: [LoadingService],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class GifDetailComponent implements OnInit {
  colours = COLOURS;
  slug: string;
  gif$: Observable<Gif>;
  user$ = merge(
    this.authService.user$,
    this.gifService.favoriteGif$.pipe(
      catchError(err => {
        this.messagesService.showErrors(err);
        throw err;
      })
    )
  );

  constructor(
    private route: ActivatedRoute,
    private gifService: GiftDetailService,
    private authService: AuthService,
    private messagesService: MessageService,
    public loadingService: LoadingService
  ) {
    this.slug = this.route.snapshot.params['slug'];
  }

  ngOnInit(): void {
    this.loadingService.showLoading();

    this.gif$ = this.gifService.getGiftDetail(this.slug).pipe(
      finalize(() => this.loadingService.hideLoading()),
      map((gif: Gif) => ({
        ...gif,
        isFavorite: false
      }))
    );
  }

  favoriteGif(gifId: number) {
    this.gifService.favoriteGif(gifId);
  }

}
