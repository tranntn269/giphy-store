import { ROUTE } from './../../../../shared/constants/route';
import { TranslateService } from '@ngx-translate/core';
import { LoadingService } from './../../../../core/sevices/loading.service';
import { MessageService } from 'src/app/modules/core/components/messages/messages.service';
import { AuthService } from 'src/app/modules/core/auth/auth.service';
import { PAGINATION } from './../../../../shared/constants/pagination.constant';
import { catchError, map, scan } from 'rxjs/operators';
import { tap, Subscription, combineLatest, startWith, merge } from 'rxjs';
import { COLOURS } from 'src/app/modules/shared/constants';
import { Component, OnInit, OnDestroy, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { GifService } from '../../services/gifs.service';
import { Gif } from '../../models';
import { GiftDetailService } from '../../services/gif-detail.service';

@Component({
  selector: 'gif-list',
  templateUrl: './gif-list.component.html',
  styleUrls: ['./gif-list.component.scss'],
  providers: [LoadingService],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class GifListComponent implements OnInit, OnDestroy {
  emptyPage = {
    title: this.translateService.instant('empty-gif.upload-your-first-gif'),
    url: `${ROUTE.MAIN}/${ROUTE.UPLOAD}`
  }

  readonly iconPath = 'assets/imgs/figma-store/word-symbols';
  colours = COLOURS;
  pageIndex = PAGINATION.PAGEINDEX;
  pageSize = PAGINATION.PAGESIZE;

  gifs: Gif[] = [];
  noMoreGif: boolean = true; // this client has fetched everything, set to 'true' to hide the spinner and stop the infinity scroll

  subscriptions: Subscription[] = []
  scrollEnd$ = this.gifService.scrollEnd$;

  favoriteGifLists$ = merge(   //use merge to listen when new page is loaded OR when user click favorite a gif
    combineLatest([this.gifService.paginatedGifs$, this.authService.user$]).pipe(
      map(([list, user]) => {     //for everyGifId in favouriteArr, update gifItem: {...gifItem, isFavorite: true}
        const cloneArr = list.map(el => ({
          ...el,
          isFavorite: false
        }));

        if (user?.favorites && cloneArr.length > 0) {
          for (let i = 0; i < user.favorites.length; i++) {
            this.updateFavoriteGif(cloneArr, user.favorites[i]);  //gifItem: {...gifItem, isFavorite: true}
          }
        }
        return cloneArr;
      })
    ),
    this.gifDetailService.favoriteGif$.pipe(
      catchError(err => {
        this.messagesService.showErrors(err);   //catch Error when favorite http request return error
        throw err;
      })
    )
  ).pipe(
    // tap(data => console.log(data)),
    scan((gifList, value) => {            //update gifList when user click favorite. (acc, cur),[]
      return this.modifyGifs(gifList, value);
    }, [] as Gif[]),
    // tap(data => console.log(data))
  );

  modifyGifs(gifList: Gif[], value: any) {
    if (!(value instanceof Array)) {
      if (typeof value === 'number') {
        this.updateFavoriteGif(gifList, value);
      }
    }
    else { return value; }
    return gifList;
  }

  updateFavoriteGif(arr: Gif[], id: number): void {
    if (arr.length === 0) {
      return;
    }


    let gifIdx = arr.findIndex(el => el.id === id);
    if (gifIdx !== -1) {
      arr[gifIdx].isFavorite = true;
    }
  }

  gifLists$ = combineLatest([
    this.gifService.sort$,
    this.gifService.searchString$.pipe(startWith('')),
    this.favoriteGifLists$
  ]).pipe(
    tap(([sortOrder, searchString, gifLists]) => {
      this.loadingService.hideLoading();

      if (gifLists == []) {
        this.noMoreGif = true;
        return;
      }

      this.gifs = [...this.gifs, ...gifLists];
      this.gifs = this.gifService.filterGif(searchString, this.gifs).sort(
        this.gifService.sortGifByLastUpdate
      );

      if (sortOrder == "desc") {
        this.gifs = this.gifs.reverse();
      }

      if (gifLists.length < this.pageSize) {
        this.noMoreGif = true;
      };
    })
  );


  constructor(
    private cdr: ChangeDetectorRef,
    public gifService: GifService,
    private authService: AuthService,
    private gifDetailService: GiftDetailService,
    private messagesService: MessageService,
    private loadingService: LoadingService,
    private translateService: TranslateService,
  ) { }


  ngOnInit(): void {

    this.loadingService.showLoading();
    this.scrollEnd();
  }

  //this method receives the scrollEndEvent and updates the pagination Subject.
  scrollEnd() {
    const subscription$ = this.scrollEnd$.pipe(
      tap(
        _ => {
          const offset = Math.floor(this.gifs.length / this.pageSize) + 1;
          if (this.pageIndex !== offset) {
            this.noMoreGif = false;
            this.cdr.markForCheck();

            this.gifService.updatePaginationSubject({
              pageIndex: offset,
              pageSize: this.pageSize
            });
          }
          this.pageIndex = offset;
        }
      )
    ).subscribe();
    this.subscriptions.push(subscription$)

  }

  sort(event: any) {
    this.gifService.updateSortSubject(event);
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((subscription) => subscription.unsubscribe())
  }
}
