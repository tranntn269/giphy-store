import { GiftDetailService } from './../../services/gif-detail.service';
import { COLOURS } from 'src/app/modules/shared/constants';
import { Component, OnInit, Input } from '@angular/core';
import { Gif } from '../../models';
import { AuthService } from 'src/app/modules/core/auth';

@Component({
  selector: 'app-gif',
  templateUrl: './gif.component.html',
  styleUrls: ['./gif.component.scss']
})

export class GifComponent implements OnInit {
  @Input() item: Gif;
  colours = COLOURS;

  user$ = this.authService.user$;

  constructor(
    private gifDetailService: GiftDetailService,
    private authService: AuthService,
  ) { }

  ngOnInit(): void {
    this.renderBg();
  }


  renderBg() {
    const totalBg = 21;
    const bgPath = 'assets/imgs/figma-store/bg';
    const randomNum = Math.round(Math.random() * totalBg);

    this.item.bgImg = `${bgPath}/bg${randomNum}.jpg`;

  }

  navigateToGif(slug: string) {
  }

  getAllGifs() {

  }

  favoriteGif(gifId: number) {
    this.gifDetailService.favoriteGif(gifId);
  }

}
