import { PAGINATION } from './../../../../shared/constants/pagination.constant';
import { ScrollEventService } from './../../services/scroll.service';
import { UserService } from './../../services/users.service';
import { User } from './../../models/user.model';
import { Dialog } from '@angular/cdk/dialog';
import { COLOURS, ROUTE } from 'src/app/modules/shared/constants';
import { Component, OnInit, ViewChild, ElementRef, ChangeDetectionStrategy, AfterViewInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { tags } from 'server/data';
import { AuthService } from 'src/app/modules/core/auth/auth.service';
import { Observable, Subject, takeUntil, tap } from 'rxjs';
import { GifService } from '../../services/gifs.service';
import { TagService } from '../../services/tags.service';

const NAV_HEIGHT = 86;

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class HeaderComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('wrapper') wrapper: ElementRef;
  @ViewChild('searchWrapper') searchWrapper: ElementRef;
  colours = COLOURS;
  route = ROUTE;
  tags = tags;
  isSearch = false;
  isScroll = false;
  isMobileMenuOpen = false;

  destroy = new Subject();
  destroy$ = this.destroy.asObservable();
  user$: Observable<User | null>;

  constructor(
    public dialog: Dialog,
    private authService: AuthService,
    private gifService: GifService,
    private tagService: TagService,
    private userSerive: UserService,
    private scrollSerive: ScrollEventService,
    private cdr: ChangeDetectorRef
  ) { }


  ngOnInit(): void {
    this.user$ = this.authService.user$;
    //demo optimize input
    // this.trackSearchInput();
  }

  // trackSearchInput() {
  //   this.searchInput.valueChanges.pipe(debounceTime(700)).subscribe((searchWord: string) => {
  //     this.gifService.updateSearchStringSubject(searchWord);
  //   })
  // }

  ngAfterViewInit(): void {
    this.listenScroll();
  }

  listenScroll() {
    this.scrollSerive.scrollEvent$.pipe(
      takeUntil(this.destroy$),
      tap(e => {
        const offset = e || 0;
        if (offset > NAV_HEIGHT) {
          this.isScroll = true;
          this.cdr.detectChanges();
          this.wrapper.nativeElement.classList.add('white-bg');
        }
        else {
          this.isScroll = false;
          this.cdr.detectChanges();

          this.wrapper.nativeElement.classList.remove("white-bg");
        }
      })
    ).subscribe();
  }

  setIsSearch() {
    this.isSearch = !this.isSearch;
    if (this.isSearch) {
      this.searchWrapper.nativeElement.classList.add("full-height");
    }
    else this.searchWrapper.nativeElement.classList.remove("full-height");
  }

  openMobileMenu(event: any) {

  }

  logOut() {
    this.authService.logout();
  }


  updateSearch() {

    this.gifService.updateSearchStringSubject('');
    this.userSerive.updateSearchUserSubject(null);
    this.tagService.updateSearchTagSubject(null);
    this.gifService.updateSortSubject('desc');
    this.gifService.updatePaginationSubject({
      pageIndex: PAGINATION.PAGEINDEX,
      pageSize: PAGINATION.PAGESIZE,
    })
  }

  ngOnDestroy(): void {
    this.destroy.next(true);
  }
}
