import { COLOURS } from 'src/app/modules/shared/constants';
import { ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'heart-beat',
  templateUrl: './heart-beat.component.html',
  styleUrls: ['./heart-beat.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class HeartBeatComponent implements OnInit {
  colours = COLOURS;

  @Input() isFavorite: boolean | undefined;
  constructor() { }

  ngOnInit(): void {

  }

}
