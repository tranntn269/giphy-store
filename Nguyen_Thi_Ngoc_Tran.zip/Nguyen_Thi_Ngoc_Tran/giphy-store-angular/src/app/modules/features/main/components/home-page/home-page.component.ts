import { ScrollEventService } from './../../services/scroll.service';
import { GifService } from './../../services/gifs.service';
import { ChangeDetectionStrategy, Component, OnInit, ViewChild, ElementRef, AfterViewInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { takeUntil, fromEvent, Subject, tap } from 'rxjs';

const HEADER_HIDE_THRESHOLD = 400;
const NAV_HEIGHT = 72;

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class HomePageComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('wrapper', { static: true }) wrapper: ElementRef;
  isHeaderVisible = true;
  previousScroll: number;

  destroy = new Subject();
  destroy$ = this.destroy.asObservable();

  constructor(
    private gifService: GifService,
    private cf: ChangeDetectorRef,
    private scrollEvent: ScrollEventService
  ) { }


  ngOnInit(): void {
  }

  ngAfterViewInit(): void {
    fromEvent(this.wrapper.nativeElement, 'scroll')
      .pipe(
        takeUntil(this.destroy$),
        tap((e: any) => {
          const currentScroll = (e.target as Element).scrollTop;
          this.scrollEvent.updateScrollPosition(currentScroll);

          if (typeof this.previousScroll !== 'number') {
            this.previousScroll = currentScroll;
            return;
          }

          const direction = currentScroll > this.previousScroll ? 'down' : 'up';

          if (this.isHeaderVisible && direction === 'down') {
            this.isHeaderVisible = false;
            this.cf.detectChanges();

          } else if (!this.isHeaderVisible && direction === 'up') {
            this.isHeaderVisible = true;
            this.cf.detectChanges();

          }

          this.previousScroll = currentScroll;
        })
      )
      .subscribe();
  }

  scrollEnd(event: any) {
    this.gifService.emitSrollEndEvent();
  }

  ngOnDestroy(): void {
    this.destroy.next(true);
  }
}
