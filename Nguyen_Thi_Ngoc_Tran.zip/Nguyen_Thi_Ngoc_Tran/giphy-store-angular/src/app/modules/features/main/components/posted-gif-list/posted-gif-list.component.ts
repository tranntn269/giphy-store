import { TranslateService } from '@ngx-translate/core';
import { finalize } from 'rxjs';
import { LoadingService } from './../../../../core/sevices/loading.service';

import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { PostedGifService } from '../../services/posted-gif.service';
import { ROUTE } from 'src/app/modules/shared/constants';


@Component({
  selector: 'app-posted-gif-list',
  templateUrl: './posted-gif-list.component.html',
  styleUrls: ['./posted-gif-list.component.scss', './../favorite-gif-list/favorite-gif-list.component.scss'],
  providers: [LoadingService],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PostedGifListComponent implements OnInit {

  emptyPage = {
    title: this.translateService.instant('empty-gif.see-all-gifs'),
    url: `${ROUTE.MAIN}/${ROUTE.UPLOAD}`
  }

  gifs$ = this.postedGifService.postedGif$.pipe(
    finalize(() => this.loadingService.hideLoading())
  )

  constructor(
    public postedGifService: PostedGifService,
    private loadingService: LoadingService,
    private translateService: TranslateService
  ) { }

  ngOnInit(): void {
    this.loadingService.showLoading();
  }

}
