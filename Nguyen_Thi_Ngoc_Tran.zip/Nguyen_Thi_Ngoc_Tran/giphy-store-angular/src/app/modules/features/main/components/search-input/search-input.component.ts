import { TrackkingSearchService } from './../../services/track-search.service';
import { LoadingService } from './../../../../core/sevices/loading.service';
import { map, } from 'rxjs/operators';
import { TagService } from './../../services/tags.service';
import { debounceTime, combineLatest, Subscription, distinctUntilChanged } from 'rxjs';
import { Component, Input, OnInit, ViewChild, ElementRef, OnDestroy, ChangeDetectionStrategy } from '@angular/core';
import { FormControl } from '@angular/forms';
import { COLOURS } from 'src/app/modules/shared/constants';
import { GifService } from '../../services/gifs.service';
import { Tag } from '../../models';
import { UserService } from '../../services/users.service';

@Component({
  selector: 'search-input',
  templateUrl: './search-input.component.html',
  styleUrls: ['./search-input.component.scss'],
  providers: [LoadingService, TagService, UserService, TrackkingSearchService],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class SearchInputComponent implements OnInit, OnDestroy {
  subscriptions: Subscription[] = [];
  @ViewChild("searchWrapper") searchWrapper: ElementRef;
  colours = COLOURS;
  @Input() isMobile: boolean = false;
  searchInput = new FormControl();
  isSearching$ =
    this.trackSearchService.isSearching$;

  data$ = combineLatest([
    this.tagService.tagCollection$.pipe(
      map(
        (data: Tag[]) => {
          const uniqueTags = new Set(data);
          return [...uniqueTags];
        }
      )),
    this.userSerive.users$
  ]).pipe(
    map(([tags, users]) => (
      {
        tags,
        users
      }
    )),
  )

  constructor(
    private gifService: GifService,
    private tagService: TagService,
    private userSerive: UserService,
    private trackSearchService: TrackkingSearchService,
  ) { }


  ngOnInit(): void {
    this.trackSearchInput();
  }

  trackSearchInput() {
    const subscription$ = this.searchInput.valueChanges.pipe(
      debounceTime(700),
      distinctUntilChanged(),   //in case user copy and paste same value
    ).subscribe(
      (searchWord: string) => {
        const subStr = searchWord.substring(1).toLowerCase();

        if (searchWord.startsWith('@')) {
          this.searchWrapper && (this.searchWrapper.nativeElement.style.display = 'revert');
          this.userSerive.updateSearchUserSubject(subStr);
          this.tagService.updateSearchTagSubject(null);

        } else if (searchWord.startsWith('#')) {
          this.searchWrapper && (this.searchWrapper.nativeElement.style.display = 'revert');
          this.tagService.updateSearchTagSubject(subStr);
          this.userSerive.updateSearchUserSubject(null);
        } else {

          this.gifService.updateSearchStringSubject(searchWord);
          this.userSerive.updateSearchUserSubject(null);
          this.tagService.updateSearchTagSubject(null);
        }
      }
    );
    this.subscriptions.push(subscription$);
  }

  updateSearch(searchWord: string) {
    this.gifService.updateSearchStringSubject(searchWord);
    this.searchWrapper.nativeElement.style.display = 'none';
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }

}
