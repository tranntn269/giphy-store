import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { COLOURS } from 'src/app/modules/shared/constants';

@Component({
  selector: 'slogan',
  templateUrl: './slogan.component.html',
  styleUrls: ['./slogan.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SloganComponent implements OnInit {
  colours = COLOURS;
  readonly iconPath = 'assets/imgs/figma-store/word-symbols';

  constructor() { }

  ngOnInit(): void {
  }

}
