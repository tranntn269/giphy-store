import { switchMap } from 'rxjs/operators';
import { Subject, startWith } from 'rxjs';
import { FormControl } from '@angular/forms';
import { COLOURS } from 'src/app/modules/shared/constants';
import { ChangeDetectionStrategy, Component, ElementRef, OnInit, ViewChild, OnDestroy, ViewChildren, QueryList, Output, EventEmitter } from '@angular/core';
import { TagService } from '../../services/tags.service';
import { Subscription, debounceTime } from 'rxjs';
import { TrackkingSearchService } from '../../services/track-search.service';

@Component({
  selector: 'tag-input',
  templateUrl: './tag-input.component.html',
  styleUrls: ['./tag-input.component.scss'],
  providers: [TagService, TrackkingSearchService],
  changeDetection: ChangeDetectionStrategy.OnPush
})


export class TagInputComponent implements OnInit, OnDestroy {
  @ViewChild("tagCategory") tagWrapper: ElementRef;
  @ViewChild("tagItem") tagItem: ElementRef;
  @ViewChild("searchWrapper") searchWrapper: ElementRef;
  @ViewChildren("renderTag") tagList: QueryList<ElementRef>;

  colours = COLOURS;
  isDisablePlus = true;
  selectedTagName: string;
  selectedTagList: string[] = [];
  searchInput = new FormControl();
  @Output('onSelectTag') onSelectTag = new EventEmitter<string[]>();

  private searchTagSubject = new Subject<string | null>();
  private searchTag$ = this.searchTagSubject.asObservable();

  private tagNameListSubject = new Subject<string[]>();
  tagNameList$ = this.tagNameListSubject.asObservable();

  isSearching$ =
    this.trackSearchService.isSearching$;

  tagCollection$ = this.searchTag$.pipe(
    startWith(null),
    switchMap((str) => this.tagService.getTag(str)),
  )

  subscriptions: Subscription[] = [];

  constructor(
    private tagService: TagService,
    private trackSearchService: TrackkingSearchService
  ) { }

  ngOnInit(): void {
    this.trackSearchInput();
  }

  trackSearchInput() {
    const subscription$ = this.searchInput.valueChanges.pipe(
      debounceTime(700),
    ).subscribe(
      (searchWord: string) => {
        this.removeSearchWrapper();
        this.searchTagSubject.next(searchWord);
        this.trackSearchService.trackingSearch(true);

      }
    );
    this.subscriptions.push(subscription$);
  }


  selectTag(tagName: string, indexEl: number) {
    this.isDisablePlus = false;
    const tagList = this.tagList.toArray();
    tagList.forEach(
      (el: ElementRef) => el.nativeElement.classList.remove('result__item--selected')
    );

    tagList[indexEl].nativeElement.classList.add('result__item--selected');
    this.selectedTagName = tagName;
  }

  modifySelectedTagList(tagName: string) {
    if (this.selectedTagList.indexOf(tagName) !== -1) {
      return;
    }
    this.selectedTagList = [...this.selectedTagList, tagName];
  }

  addTagName() {
    this.toggleSearchWrapper();
    this.isDisablePlus = true;
    this.modifySelectedTagList(this.selectedTagName);
    this.tagNameListSubject.next(this.selectedTagList);
    this.onSelectTag.emit(this.selectedTagList);
  }

  removeSearchWrapper() {
    this.searchWrapper && this.searchWrapper.nativeElement.classList.remove('display-none');
  }

  toggleSearchWrapper() {
    this.searchWrapper && this.searchWrapper.nativeElement.classList.add('display-none');
  }

  onRemoveTag(tag: string) {
    const index = this.selectedTagList.indexOf(tag);
    if (index > -1) {
      this.selectedTagList.splice(index, 1);
    }
    this.tagNameListSubject.next(this.selectedTagList);
    this.onSelectTag.emit(this.selectedTagList);
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }


}
