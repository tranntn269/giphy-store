import { LoadingService } from './../../../../core/sevices/loading.service';
import { Router } from '@angular/router';
import { MessageService } from 'src/app/modules/core/components/messages/messages.service';
import { GifService } from './../../services/gifs.service';
import { COLOURS, ROUTE } from 'src/app/modules/shared/constants';
import { catchError, tap, throwError, finalize } from 'rxjs';
import { Subject, takeUntil } from 'rxjs';

import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ChangeDetectionStrategy, Component, OnInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { GifRequest } from '../../models';

@Component({
  selector: 'app-upload-gif',
  templateUrl: './upload-gif.component.html',
  styleUrls: ['./upload-gif.component.scss',],
  providers: [LoadingService],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class UploadGifComponent implements OnInit, OnDestroy {
  @ViewChild('imgTmpl') imgTmpl: ElementRef;
  @ViewChild('imgWrapper') imgWrapper: ElementRef;

  colours = COLOURS;
  uploadForm: FormGroup;

  validateForm$ = new BehaviorSubject<boolean>(false);
  destroy = new Subject();
  destroy$ = this.destroy.asObservable();

  constructor(
    private router: Router,
    private fb: FormBuilder,
    private gifService: GifService,
    private messagesService: MessageService,
    private loadingService: LoadingService,

  ) { }


  ngOnInit(): void {
    this.initForm();
  }

  initForm() {
    this.uploadForm = this.fb.group({
      title: ['', Validators.required],
      tags: [null, Validators.required],
      imgBase64: [null, Validators.required]
    })
  }

  addImg() {

  }

  submitForm() {
    this.validateForm$.next(true);
    if (this.uploadForm.status == 'VALID') {

      const request: GifRequest = {
        title: this.uploadForm.value.title,
        tags: this.uploadForm.value.tags,
        imgBase64: this.uploadForm.value.imgBase64
      }

      this.loadingService.showLoading();

      this.gifService.uploadGif(request).pipe(
        takeUntil(this.destroy$),
        finalize(() => this.loadingService.hideLoading()),
        tap(res => {
          this.router.navigate([`/${ROUTE.MAIN}/${res.slug}`])
        }),
        catchError(err => {
          const message = "There're some errors occur...";
          this.messagesService.showErrors(message);
          return throwError(err);
        })
      ).subscribe();
    }
  }

  handleFileInput(event: Event) {
    const element = event.currentTarget as HTMLInputElement;
    const fileList: FileList | null = element.files;

    if (fileList != null) {
      const file = fileList[0];
      const reader = new FileReader();
      reader.readAsDataURL(file);
      this.imgTmpl.nativeElement.src = URL.createObjectURL(file);

      reader.onerror = (error) => {
        console.log('Error: ', error);
      };
      reader.onloadend = () => {
        URL.revokeObjectURL(this.imgTmpl.nativeElement.src);
        this.imgWrapper.nativeElement.classList.add('fit-content');

        // Read complete
        if (reader.readyState === 2) {
          const base64result = reader.result;
          this.uploadForm.get('imgBase64')?.patchValue(base64result);
          this.uploadForm.updateValueAndValidity();
        }
      };
    }
  }

  updateTagFormValue(event: string[]) {
    this.uploadForm.get('tags')?.patchValue(event);
    this.uploadForm.updateValueAndValidity();
  }

  ngOnDestroy(): void {
    this.destroy.next(true);
  }


}
