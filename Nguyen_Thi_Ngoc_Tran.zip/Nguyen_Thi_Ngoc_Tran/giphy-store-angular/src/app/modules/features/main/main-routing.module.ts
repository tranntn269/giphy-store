import { PostedGifListComponent } from './components/posted-gif-list/posted-gif-list.component';
import { FavoriteGifListComponent } from './components/favorite-gif-list/favorite-gif-list.component';
import { UploadGifComponent } from './components/upload-gif/upload-gif.component';
import { GifDetailComponent } from './components/gif-detail/gif-detail.component';
import { CollectionComponent } from './components/collection/collection.component';

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ROUTE } from '../../shared/constants';
import { HomePageComponent } from './components/home-page/home-page.component';
import { AuthGuard } from '../../core/auth';

const routes: Routes = [{
  path: '',
  component: HomePageComponent,
  children: [
    {

      path: ROUTE.FAVORITE,
      component: FavoriteGifListComponent
    },
    {
      path: ROUTE.UPLOADED,
      component: PostedGifListComponent
    },
    {
      path: ROUTE.COLLECTION,
      component: CollectionComponent,

    },
    {
      path: ROUTE.UPLOAD,
      component: UploadGifComponent,
      canActivate: [AuthGuard],
    },
    {
      path: ":slug",
      component: GifDetailComponent
    },
    {
      path: '',
      redirectTo: ROUTE.COLLECTION,
      pathMatch: 'full',
    },
  ],
},

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MainRoutingModule { }
