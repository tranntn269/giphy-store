import { EmptyGifComponent } from './components/empty-gif/empty-gif.component';
import { MessageService } from 'src/app/modules/core/components/messages/messages.service';
import { HeartBeatComponent } from './components/heart-beat/heart-beat.component';
import { CollectionComponent } from './components/collection/collection.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MainRoutingModule } from './main-routing.module';
import { SharedModule } from '../../shared/shared.module';

import { HeaderComponent } from './components/header/header.component';
import { MobileNavComponent } from './components/mobile-nav/mobile-nav.component';
import { DraggableSliderComponent } from './components/draggable-slider/draggable-slider.component';
import { GifListComponent } from './components/gif-list/gif-list.component';
import { FooterComponent } from './components/footer/footer.component';
import { ExploreTagComponent } from './components/explore-tag/explore-tag.component';
import { SloganComponent } from './components/slogan/slogan.component';
import { GifComponent } from './components/gif/gif.component';
import { SearchInputComponent } from './components/search-input/search-input.component';
import { GifDetailComponent } from './components/gif-detail/gif-detail.component';
import { HomePageComponent } from './components/home-page/home-page.component';
import { FavoritePipe } from './pipes/isFavorite.pipe';
import { UploadGifComponent } from './components/upload-gif/upload-gif.component';
import { TagInputComponent } from './components/tag-input/tag-input.component';
import { FavoriteGifListComponent } from './components/favorite-gif-list/favorite-gif-list.component';
import { PostedGifListComponent } from './components/posted-gif-list/posted-gif-list.component';


@NgModule({
  declarations: [
    FavoritePipe,
    HomePageComponent,
    HeaderComponent,
    MobileNavComponent,
    DraggableSliderComponent,
    GifListComponent,
    FooterComponent,
    ExploreTagComponent,
    SloganComponent,
    GifComponent,
    SearchInputComponent,
    CollectionComponent,
    GifDetailComponent,
    HeartBeatComponent,
    UploadGifComponent,
    TagInputComponent,
    FavoriteGifListComponent,
    PostedGifListComponent,
    EmptyGifComponent
  ],
  imports: [
    CommonModule,
    MainRoutingModule,
    SharedModule,
  ],
  providers: [
    MessageService
  ]
})
export class MainModule { }
