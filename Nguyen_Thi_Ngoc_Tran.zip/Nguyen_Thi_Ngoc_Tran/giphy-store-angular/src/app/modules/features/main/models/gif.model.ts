export interface Gif {
  id: number;
  slug: string;
  title: string;
  url: string;
  imgBase64?: string;
  username: string;
  tags: string[];
  rating?: number;
  score?:number;
  createdAt?: number | Date;
  lastUpdated: number | Date;
  bgImg?: string;
  isFavorite?: boolean;
}

export interface GifRequest {
  title: string;
  imgBase64: string;
  tags: string[];
}
