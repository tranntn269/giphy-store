export interface Pagination {
  pageIndex: number,
  pageSize: number
}
