export interface User {
  username: string;
  password?: string;
  role?: string;
  favorites?: number[];
  token?: string
}



