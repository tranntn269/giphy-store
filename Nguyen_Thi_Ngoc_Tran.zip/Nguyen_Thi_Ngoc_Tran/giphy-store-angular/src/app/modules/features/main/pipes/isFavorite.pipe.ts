import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'isFavorite'
})

export class FavoritePipe implements PipeTransform {
  transform(value: any, arr: any, id: number, ...args: any[]) {
    if (arr && arr.length !== 0) {
      return this.checkIsFavorite(arr as number[], id);
    }
    return false;
  }

  checkIsFavorite(listFavorites: number[], gifId: number): boolean {
    if (listFavorites.indexOf(gifId) !== -1) return true;
    return false;
  }

}
