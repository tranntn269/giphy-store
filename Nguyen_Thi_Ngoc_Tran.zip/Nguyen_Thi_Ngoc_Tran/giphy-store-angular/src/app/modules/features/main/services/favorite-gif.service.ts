import { Gif } from './../models/gif.model';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Injectable } from "@angular/core";

@Injectable({
  providedIn: 'root'
})

export class FavoriteGifService {
  baseUrl = environment.apiUrl;


  favoriteGifList$ = this.http.get<Gif[]>(`${this.baseUrl}/gifs/favourite`);

  constructor(private http: HttpClient) {

  }
}
