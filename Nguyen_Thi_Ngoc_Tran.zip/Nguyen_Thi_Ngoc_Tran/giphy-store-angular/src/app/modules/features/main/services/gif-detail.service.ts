import { AuthService } from 'src/app/modules/core/auth/auth.service';
import { map, Observable, Subject, catchError, tap, exhaustMap } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Gif } from './../models/gif.model';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from "@angular/core";
import { User } from '../models';

@Injectable({
  providedIn: 'root'
})

export class GiftDetailService {
  baseUrl = environment.apiUrl;

  private gifIdSubject$ = new Subject<number>();
  gifId$ = this.gifIdSubject$.asObservable();

  favoriteGif$ = this.gifId$.pipe(
    exhaustMap((gifId: number) =>
      this.updateUserFavorite(gifId).pipe(
        tap(data => {
          this.authService.updateUserInfo(data);
        }
        ),
        catchError(err => {
          const message = "Some errors occur...";
          throw message;
        })
      )
    )
  );

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {

  }

  favoriteGif(gifId: number) {
    this.gifIdSubject$.next(gifId);
  }

  updateUserFavorite(gifId: number): Observable<User> {
    return this.http.patch<User>(`${this.baseUrl}/user`, {
      gifId
    }).pipe(
      // delay(3000),    //add delay for testing exhaustMap
      map((data: any) => data.user)
    )
  }

  getGiftDetail(slug: string) {
    let params = new HttpParams();
    params = params.append('slug', slug);

    return this.http.get<Gif>(`${this.baseUrl}/gif`, {
      params
    });
  }


}
