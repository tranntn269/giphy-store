import { PAGINATION } from './../../../shared/constants/pagination.constant';
import { switchMap } from 'rxjs/operators';
import { environment } from './../../../../../environments/environment';
import { BehaviorSubject, Subject, shareReplay, } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from "@angular/core";
import { Gif, GifRequest } from '../models';
import { Pagination } from '../models/pagination.model';

@Injectable({
  providedIn: 'root'
})

export class GifService {
  baseUrl = environment.apiUrl;

  private paginationSubject = new BehaviorSubject<Pagination>({
    pageIndex: PAGINATION.PAGEINDEX,
    pageSize: PAGINATION.PAGESIZE,
  });
  public pagination$ = this.paginationSubject.asObservable();

  private searchStringSubject = new Subject<string>();
  public searchString$ = this.searchStringSubject.asObservable();

  private sortSubject = new BehaviorSubject<string>('desc');
  public sort$ = this.sortSubject.asObservable();

  private scrollEndSubject = new Subject<boolean>();
  public scrollEnd$ = this.scrollEndSubject.asObservable();

  paginatedGifs$ = this.pagination$.pipe(
    switchMap(
      (pagination: Pagination) => {
        let params = new HttpParams();
        params = params.append('_page', pagination.pageIndex);
        params = params.append('_limit', pagination.pageSize);

        return this.http.get<Gif[]>(`${this.baseUrl}/gifs`, { params })
      })
  ).pipe(shareReplay(1));


  sortGifByLastUpdate(g1: Gif, g2: Gif) {
    return (g1.lastUpdated as number) - (g2.lastUpdated as number);
  }


  filterGif(str: string, arr: Gif[]) {
    const cloneArr = [...new Map(arr.map(item => [item.id, item])).values()];

    if (str.startsWith('@')) {
      return cloneArr.filter(gif => gif.username === (str.substring(1).toLowerCase()))
    } else if (str.startsWith('#')) {
      return cloneArr.filter(gif => gif.tags.includes(str.substring(1)))
    }
    else {
      return cloneArr.filter(gif => gif.title.toLowerCase().includes(str.toLowerCase()))
    }
  }


  constructor(private http: HttpClient) {

  }

  updatePaginationSubject = (pagination: Pagination): void => {
    this.paginationSubject.next(pagination);
  }

  updateSearchStringSubject = (searchString: string): void => {
    this.searchStringSubject.next(searchString);
  }

  updateSortSubject = (sort: string): void => {
    this.sortSubject.next(sort);
  }


  emitSrollEndEvent() {
    this.scrollEndSubject.next(true);
  }

  uploadGif(gif: GifRequest) {
    return this.http.post<Gif>(`${this.baseUrl}/gifs`, { ...gif });
  }


}
