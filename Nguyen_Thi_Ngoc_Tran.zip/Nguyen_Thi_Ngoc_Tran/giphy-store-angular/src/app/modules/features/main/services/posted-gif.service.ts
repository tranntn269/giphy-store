import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Injectable } from "@angular/core";
import { Gif } from '../models';

@Injectable({ providedIn: 'root' })

export class PostedGifService {
  baseUrl = environment.apiUrl;

  postedGif$ = this.http.get<Gif[]>(`${this.baseUrl}/gifs/posted`);

  constructor(private http: HttpClient) {

  }
}
