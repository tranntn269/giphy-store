import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable({
  providedIn: 'root'
})

export class ScrollEventService {
  private scrollEventSubject = new Subject<number>();
  public scrollEvent$ = this.scrollEventSubject.asObservable();

  updateScrollPosition(val: number) {
    this.scrollEventSubject.next(val);
  }
}
