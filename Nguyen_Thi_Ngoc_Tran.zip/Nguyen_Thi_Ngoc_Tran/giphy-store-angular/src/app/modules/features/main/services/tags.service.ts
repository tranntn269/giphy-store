import { environment } from './../../../../../environments/environment';
import { finalize, switchMap } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { Injectable } from "@angular/core";
import { Subject, startWith, of } from 'rxjs';
import { Tag } from '../models';
import { TrackkingSearchService } from './track-search.service';

@Injectable({
  providedIn: 'root'
})

export class TagService {
  token = localStorage.getItem('token') as string;
  baseUrl = environment.apiUrl;

  private searchTagSubject = new Subject<string | null>();
  public searchTag$ = this.searchTagSubject.asObservable();

  tagCollection$ = this.searchTag$.pipe(
    startWith(null),
    switchMap((str) => this.getTag(str))
  )

  constructor(private http: HttpClient,
    private trackSearchService: TrackkingSearchService) {
  }
  updateSearchTagSubject = (search: string | null): void => {
    this.searchTagSubject.next(search);
  }

  getTag(str: string | null) {
    if (str && str !== '') {
      this.trackSearchService.trackingSearch(true);

      return this.http.get<Tag[]>(`${this.baseUrl}/tags`, {
        headers: {
          'Authorization': JSON.parse(this.token)
        },
        params: {
          'q': str!
        }
      }).pipe(
        finalize(() => this.trackSearchService.trackingSearch(false))
      )
    }
    else return of([]);
  }
}
