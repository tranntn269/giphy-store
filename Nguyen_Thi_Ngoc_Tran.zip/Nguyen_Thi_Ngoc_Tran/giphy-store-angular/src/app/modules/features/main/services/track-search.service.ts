import { BehaviorSubject } from 'rxjs';
import { Injectable } from "@angular/core";

@Injectable({
  providedIn: 'root'
})

export class TrackkingSearchService {
  private isSearchingSubject = new BehaviorSubject<boolean>(false);
  isSearching$ = this.isSearchingSubject.asObservable();

  trackingSearch(val: boolean) {
    this.isSearchingSubject.next(val);
  }

  constructor() {
  }
}
