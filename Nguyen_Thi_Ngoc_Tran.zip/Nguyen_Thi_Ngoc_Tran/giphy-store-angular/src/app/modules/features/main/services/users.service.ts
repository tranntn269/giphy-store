import { User } from 'src/app/modules/features/main/models';
import { switchMap } from 'rxjs/operators';
import { Subject, startWith, of, finalize } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from "@angular/core";
import { environment } from 'src/environments/environment';
import { TrackkingSearchService } from './track-search.service';

@Injectable({
  providedIn: 'root'
})


export class UserService {
  token = localStorage.getItem('token') as string;
  baseUrl = environment.apiUrl;

  private searchUserSubject = new Subject<string | null>();
  public searchUser$ = this.searchUserSubject.asObservable();

  users$ = this.searchUser$.pipe(
    startWith(null),
    switchMap((str) => {
      if (str && str !== '') {
        this.trackSearchService.trackingSearch(true);

        return this.http.get<User[]>(`${this.baseUrl}/Users`, {
          headers: {
            'Authorization': JSON.parse(this.token)
          },
          params: {
            'q': str!
          }
        }).pipe(
          finalize(() => this.trackSearchService.trackingSearch(false))
        )
      }
      else return of([]);
    })
  )


  constructor(
    private http: HttpClient,
    private trackSearchService: TrackkingSearchService
  ) {

  }
  updateSearchUserSubject = (search: string | null): void => {
    this.searchUserSubject.next(search);
  }
}
