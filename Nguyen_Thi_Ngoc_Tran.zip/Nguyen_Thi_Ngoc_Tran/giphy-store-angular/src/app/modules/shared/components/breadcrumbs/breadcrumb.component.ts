import { Component, Input, OnInit } from '@angular/core';
import { Decoration } from '../../models';

@Component({
  selector: 't-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.scss']
})
export class BreadcrumbComponent implements OnInit {
  @Input() decorations: Decoration;
  constructor() { }

  ngOnInit(): void {
    console.log(this.decorations);
  }

}
