import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'button-table',
  templateUrl: './button-table.component.html',
  styleUrls: ['./button-table.component.scss']
})
export class ButtonTableComponent implements OnInit {

  constructor() { }
  ngOnInit(): void {
  }


}
