import { IButton } from './../../enums/button.enum';
import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { BUTTON_SIZES } from '../../enums';

@Component({
  selector: 't-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss']
})

export class ButtonComponent implements OnInit {
  @Input() size = '';
  @Input() variant = '';
  @Input() color = '';
  @Input() className = '';
  @Input('buttonStyle') buttonStyle: {
    [key: string]: string
  } = {};
  @Input() disabled = false;
  @Input('type') type = 'submit';
  buttonSize: string | number | {} | null | undefined;

  @Output() onClick = new EventEmitter<void>();

  constructor() { }

  ngOnInit(): void {
    this.buttonSize = BUTTON_SIZES[this.size];
    if (!this.buttonSize) throw new Error(`'Unknow size passsed to Button ${this.size}`);
  }


  onClickHandler() {
    if (this.disabled) return;
    this.onClick.emit();
  }


}
