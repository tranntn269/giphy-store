import { COLOURS } from 'src/app/modules/shared/constants';
import { DialogRef } from '@angular/cdk/dialog';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mobile-navbar',
  templateUrl: './mobile-navbar.component.html',
  styleUrls: ['./mobile-navbar.component.scss']
})
export class MobileNavBarComponent implements OnInit {
  colours = COLOURS;
  constructor(
    public dialogRef: DialogRef<MobileNavBarComponent>,
    // @Inject(DIALOG_DATA) public data: any
  ) { }

  ngOnInit(): void {
  }

  closeDialog() {
    this.dialogRef.close()
  }

}
