import { Dialog } from '@angular/cdk/dialog';
import { Component, OnInit } from '@angular/core';
import { COLOURS } from '../../constants';
import { MobileNavBarComponent } from './mobile-navbar/mobile-navbar.component';

@Component({
  selector: 'navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavBarComponent implements OnInit {
  colours = COLOURS;
  constructor(public dialog: Dialog) { }

  ngOnInit(): void {
  }

  openDialog() {
    this.dialog.open(MobileNavBarComponent, {
      minWidth: '300px'
    });
  }

}
