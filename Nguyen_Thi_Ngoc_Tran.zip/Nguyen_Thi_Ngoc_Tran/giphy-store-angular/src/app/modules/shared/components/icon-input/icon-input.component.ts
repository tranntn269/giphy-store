import { FormControl } from '@angular/forms';
import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Decoration } from '../../models';

interface ISizes {
  fontSize: number,
  iconSize: number,
  borderThickness: number,
  height: number,
}


interface IStyles {
  [key: string]: ISizes
}

const STYLES: IStyles = {
  small: {
    fontSize: 14 / 16,
    iconSize: 16 / 16,
    borderThickness: 1,
    height: 24 / 16
  },
  large: {
    fontSize: 18 / 16,
    iconSize: 24 / 16,
    borderThickness: 2,
    height: 36 / 16
  }
}


@Component({
  selector: 't-icon-input',
  templateUrl: './icon-input.component.html',
  styleUrls: ['./icon-input.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class IconInputComponent implements OnInit {
  styles: ISizes;
  @Input() size: string;
  @Input() width: number;
  @Input() percent: number;
  @Input() icon: string;
  @Input() placeholder = '';
  @Input() label = '';
  @Input() decorations: Decoration;
  @Input() inputName: FormControl = new FormControl();
  @Output('onClick') click = new EventEmitter();

  constructor() { }

  ngOnInit(): void {
    this.styles = STYLES[this.size];
  }

  onClick(event: Event) {
    this.click.emit(event);
  }

}
