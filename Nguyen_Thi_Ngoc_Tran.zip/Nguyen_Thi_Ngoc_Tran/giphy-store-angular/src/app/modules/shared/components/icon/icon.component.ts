import { Decoration } from './../../models/decoration.model';
import { ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';
import { Icons } from '../../enums';



@Component({
  selector: 't-icon',
  templateUrl: './icon.component.html',
  styleUrls: ['./icon.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class IconComponent implements OnInit {
  readonly iconPath = 'assets/imgs/icons/icon.svg';
  @Input() size: number;
  @Input() strokeWidth = 1;
  @Input() id: Icons | string;
  @Input() decorations?: Decoration;

  constructor() { }

  ngOnInit(): void {
  }

}
