import { Component, Input, OnInit } from '@angular/core';

const STYLES: { [key: string]: any; } = {
  small: {
    height: 8,
    radius: 4
  },
  medium: {
    height: 12,
    radius: 4
  },
  large: {
    height: 16,
    padding: 4,
    radius: 8
  }
}


@Component({
  selector: 't-progress-bar',
  templateUrl: './progress-bar.component.html',
  styleUrls: ['./progress-bar.component.scss']
})

export class ProgressBarComponent implements OnInit {
  @Input() size = '';
  @Input() value = '';
  progressBar: { [key: string]: any } = {};


  constructor() { }

  ngOnInit(): void {
    this.progressBar = STYLES[this.size];
    if (!this.progressBar) throw new Error(`'Unknow size passed to ProgressBar ${this.size}`);
  }

}
