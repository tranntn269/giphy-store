// Button.stories.ts

import { Meta, Story } from '@storybook/angular';
import { ProgressBarComponent } from './progress-bar.component';


export default {
  /* 👇 The title prop is optional.
  * See https://storybook.js.org/docs/angular/configure/overview#configure-story-loading
  * to learn how to generate automatic titles
  */
  title: 'ProgressBar',
  component: ProgressBarComponent,
  //👇 Creates specific argTypes
  argTypes: {
    // backgroundColor: { control: 'color' },
    value: {
      control: {
        type: "number",
        min: 0,
        max: 100,
      }
    },
    size: {
      control: {
        type: "select",
        options: ["small", "medium", "large"]
      }
    }
  },
  args: {
    //👇 Now all Button stories will be primary.
    primary: true,
  },
} as Meta;


//👇 We create a “template” of how args map to rendering
const Template: Story = (args) => ({
  props: args,
});

export const Default = Template.bind({});
Default.args = {
  //👇 The args you need here will depend on your component
};
