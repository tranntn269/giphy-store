import { AfterViewInit, ChangeDetectionStrategy, ChangeDetectorRef, Component, DoCheck, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { Icons } from '../../enums';
import { Decoration } from '../../models';

@Component({
  selector: 't-select',
  templateUrl: './select.component.html',
  styleUrls: ['./select.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class SelectComponent implements OnInit, AfterViewInit, DoCheck {
  @Input() value = '';
  @Input() decorations: Decoration;
  @Output('onChange') change = new EventEmitter<string>();
  @ViewChild('select') select: ElementRef;
  icons = Icons;
  selectedValue = '';
  options: Array<HTMLOptionElement>;

  constructor(private cdref: ChangeDetectorRef) { }
  ngDoCheck(): void {
    if (this.options && this.value) {
      this.selectedValue = this.getCurrentOption(this.value);
    }
  }


  ngAfterViewInit(): void {
    this.options = Array.from(this.select.nativeElement.options);

    this.selectedValue = this.getCurrentOption(this.select.nativeElement.value);
    this.cdref.detectChanges();

  }



  ngOnInit(): void {

  }


  onChange(event: Event) {
    const target = event.target as HTMLSelectElement;
    this.selectedValue = this.getCurrentOption(target.value);
    this.change.emit(target.value);
  }

  getCurrentOption(value: string) {
    return this.options.find(el => el.value === value)!.text;
  }
}
