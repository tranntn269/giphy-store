import { Component, OnInit, AfterViewInit, Input, ViewChild, ElementRef, ContentChildren, QueryList, HostListener } from '@angular/core';
import { ISlider } from '../../models';

@Component({
  selector: 't-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.scss']
})
export class SliderComponent implements OnInit, AfterViewInit {
  @Input() sliders: ISlider[];
  @ViewChild('dotContainer') dots: ElementRef;
  @ContentChildren('slide') slides: QueryList<ElementRef>

  curSlide = 0;
  maxSlide: number;

  //Handle keyboard event
  @HostListener('window:keydown', ['$event'])
  handleKeyDown(event: KeyboardEvent) {
    event.key === 'ArrowLeft' && this.prevSlide();
    event.key === 'ArrowRight' && this.nextSlide();
  }

  constructor(
    private elementRef: ElementRef,
  ) { }


  ngOnInit(): void {
    this.maxSlide = this.sliders.length;

  }

  ngAfterViewInit(): void {
    this.goToSlide();
    this.createDots();
    this.activateDot();
    this.dots.nativeElement
      .addEventListener('click', this.handleClick.bind(this));
  }

  ngOnDestroy(): void {
  }

  createDots() {
    this.sliders.forEach(
      (slide, i) => this.dots.nativeElement.insertAdjacentHTML(
        'beforeend',
        `<button
          type="button"
          role="tab" aria-label="Slide ${i + 1}" aria-selected="false" aria-controls="t-carousel-item-${i + 1}" class='dots__btn' data-slide="${i}" (click)="goToSlide(${i})" >
        </button>`
      )
    );

  }

  activateDot(curSlide: number = 0) {
    this.elementRef.nativeElement.querySelectorAll(".dots__btn").forEach(
      (dot: HTMLElement) => {
        dot.classList.remove("dots__btn--active");
        dot.setAttribute('aria-selected', 'false');
      }
    );

    const activeDot = this.elementRef.nativeElement.querySelector(`.dots__btn[data-slide='${curSlide}']`);

    if (activeDot) {
      activeDot.classList.add("dots__btn--active");
      activeDot.setAttribute('aria-selected', 'true');
    }

  }

  goToSlide(curSlide: number = 0) {
    this.slides.forEach(
      (slide, i) => {
        slide.nativeElement.style.transform = (`translateX(
          ${100 * (i - curSlide)}%)`);
      }
    )
  }

  prevSlide() {
    if (this.curSlide === 0) {
      this.curSlide = this.maxSlide - 1
    } else { this.curSlide--; }

    this.goToSlide(this.curSlide);
    this.activateDot(this.curSlide);

  }

  nextSlide() {
    if (this.curSlide === this.maxSlide - 1) {
      this.curSlide = 0;
    }
    else { this.curSlide++; }

    this.goToSlide(this.curSlide);
    this.activateDot(this.curSlide);
  }

  handleClick(event: any) {
    if (event.target.classList.contains('dots__btn')) {
      const { slide } = event.target.dataset;
      this.goToSlide(slide);
      this.activateDot(slide);
    }
  }

}
