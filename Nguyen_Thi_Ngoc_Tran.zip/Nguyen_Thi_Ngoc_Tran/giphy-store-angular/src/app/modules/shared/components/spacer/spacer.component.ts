import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 't-spacer',
  templateUrl: './spacer.component.html',
  styleUrls: ['./spacer.component.scss']
})
export class SpacerComponent implements OnInit {

  @Input() axis: 'horizontal' | 'vertical';
  @Input() size: number;

  constructor() { }

  ngOnInit(): void {

  }

  getHeight() {
    return this.axis === 'horizontal' ? 0 : this.size;
  }

  getWidth() {
    return this.axis === 'vertical' ? 0 : this.size;
  }

}
