import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';

@Component({
  selector: 't-unstyled-button',
  templateUrl: './unstyled-button.component.html',
  styleUrls: ['./unstyled-button.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UnstyledButtonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
