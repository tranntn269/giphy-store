import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';

@Component({
  selector: 'visually-hidden',
  templateUrl: './visually-hidden.component.html',
  styleUrls: ['./visually-hidden.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class VisuallyHiddenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
