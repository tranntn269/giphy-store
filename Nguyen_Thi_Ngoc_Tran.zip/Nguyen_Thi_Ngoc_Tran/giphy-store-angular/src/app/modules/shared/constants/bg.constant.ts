const iconPath = 'assets/imgs/figma-store/bg';

export const BG_COLLECTION: string[] = [
  `${iconPath}/bg0`
]
