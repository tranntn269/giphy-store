import { getColour } from "../utils"

interface IColor {
  [key: string]: string
}

export const COLOURS: IColor = {
  white: getColour('--white'),
  red: getColour('--red'),
  gray100: getColour('--gray-100'),
  gray300: getColour('--gray-300'),
  gray500: getColour('--gray-500'),
  gray700: getColour('--gray-700'),
  gray900: getColour('--gray-900')
}
