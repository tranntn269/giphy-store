export const PAGINATION = {
  PAGEINDEX: 1,
  PAGESIZE: 40,
}
