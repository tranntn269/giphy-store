export const ROUTE = {
  AUTH: 'auth',
  LOGIN: 'login',
  REGISTER: 'register',
  MAIN: 'gifs',
  COLLECTION: 'collection',
  UPLOAD: 'upload',
  ADMIN: 'admin',
  FAVORITE: 'favorite',
  UPLOADED: 'uploaded'
}

