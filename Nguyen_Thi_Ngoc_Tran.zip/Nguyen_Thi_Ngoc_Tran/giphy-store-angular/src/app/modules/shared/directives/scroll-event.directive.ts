import { AfterViewInit, Directive, ElementRef, EventEmitter, Input, Output, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appScrollEvent]'
})
export class ScrollEventDirective implements AfterViewInit {
  @Input() margin = 50;
  @Output() scrollEnd: EventEmitter<any>;
  private element: HTMLElement;

  constructor(private renderer: Renderer2, private elRef: ElementRef) {
    this.element = elRef.nativeElement;
    this.scrollEnd = new EventEmitter<any>();
  }
  public ngOnInit(): void {
    // console.log('init')
  }

  ngAfterViewInit() {
    this.renderer.listen(this.elRef.nativeElement, 'scroll', (event: TouchEvent) => {
      var diff = this.element.scrollHeight - this.element.scrollTop - this.element.clientHeight;
      if (diff <= this.margin) {
        this.scrollEnd.emit(event);
      }
    });
  }

}
