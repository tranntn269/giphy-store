export enum BUTTON_VARIANT {
  FILL = 'fill',
  OUTLINE = 'outline',
  GHOST = 'ghost'
}

export interface IButton {
  [key: string]: string | number | undefined | null | {};
}

export const BUTTON_SIZES: IButton = {
  small: {
    '--borderRadius': '2px',
    '--fontSize': `${16 / 16}rem`,
    "--padding": '4px 12px'
  },
  medium: {
    '--borderRadius': '2px',
    '--fontSize': `${18 / 16}rem`,
    "--padding": '12px 20px'
  },
  large: {
    '--borderRadius': '4px',
    '--fontSize': `${21 / 16}rem`,
    "--padding": '16px 32px'
  }
}
