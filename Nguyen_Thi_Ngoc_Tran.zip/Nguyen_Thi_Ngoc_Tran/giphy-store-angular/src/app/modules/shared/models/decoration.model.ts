export interface Decoration {
  backgroundColor?: string;
  color?: string;
  borderColor?: string
  iconColor?: string,
}
