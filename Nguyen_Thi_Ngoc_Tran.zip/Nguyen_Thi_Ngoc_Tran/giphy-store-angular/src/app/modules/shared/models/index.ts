export * from "./decoration.model";
export * from "./slider.model"
  ;
