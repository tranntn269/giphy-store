export interface ISlider {
  header: string;
  text: string;
  imgSrc: string;
  authorName: string;
  authorLocation: string;
}
