import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'isEmpty'
})

export class EmptyArr implements PipeTransform {
  transform(value: any, ...args: any[]) {
    return this.checkIsEmpty(value);
  }

  checkIsEmpty(value: any) {
    if (value === null) {
      return true;
    }

    if (value === undefined) {
      return true;
    }

    if (typeof value === 'object' && Object.keys(value).length === 0) {
      return true;
    }

    if (typeof value === 'string' && value.trim().length === 0) {
      return true;
    }

    if (value.length === 0 || value.size === 0) {
      return value.flat().length > 0 ? false : true;
    }

    return !value;

  }
}
