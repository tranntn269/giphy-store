import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'price'
})

export class FormatPrice implements PipeTransform {
  transform(value: any, ...args: any[]) {
    return this.formatPrice(value);
  }

  formatPrice(price: number): string {
    return `$${price / 100}`;
  }
}
