import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: 'pluralize'
})

export class Pluralize implements PipeTransform {
  transform(value: number, unit: string ): string {
    return this.pluralize(value, unit);
  }

  pluralize(numOfColor: number, unit: string,) {
    return numOfColor === 1 ? `1 ${unit}` : `${numOfColor} ${unit}s`
  }
}
