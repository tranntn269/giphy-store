import { CircleLoadingComponent } from './../core/components/circle-loading/circle-loading.component';
import { MessagesComponent } from './../core/components/messages/messages.component';
import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from './material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CrumbComponent } from './components/breadcrumbs/crumb/crumb.component';
import { ButtonTableComponent } from './components/button/button-table/button-table.component';
import { ButtonComponent } from './components/button/button.component';
import { IconInputComponent } from './components/icon-input/icon-input.component';
import { IconComponent } from './components/icon/icon.component';
import { ProgressBarComponent } from './components/progress-bar/progress-bar.component';
import { SelectComponent } from './components/select/select.component';
import { SpacerComponent } from './components/spacer/spacer.component';
import { UnstyledButtonComponent } from './components/unstyled-button/unstyled-button.component';
import { VisuallyHiddenComponent } from './components/visually-hidden/visually-hidden.component';
import { FormatPrice } from './pipes/formatPrice.pipe';
import { Pluralize } from './pipes/pluralize.pipe';
import { BreadcrumbComponent } from './components/breadcrumbs/breadcrumb.component';
import { NavBarComponent } from './components/header/navbar.component';
import { NavLinkComponent } from './components/header/nav-link/nav-link.component';
import { MobileNavBarComponent } from './components/header/mobile-navbar/mobile-navbar.component';
import { SliderComponent } from "./components/slider/slider.component";
import { NgxTranslateModule } from 'src/app/translate.module';
import { EmptyArr } from './pipes/empty.pipe';
import { ScrollEventDirective } from './directives/scroll-event.directive';
import { DateMonthYearPipe } from './pipes/date.pipe';
import { LoadingComponent } from '../core/components/loading/loading.component';
import { GifLoadingComponent } from '../core/components/gif-loading/gif-loading.component';
import { HorizonLoadingComponent } from '../core/components/horizon-loading/horizon-loading.component';


@NgModule({
  declarations: [
    DateMonthYearPipe,
    FormatPrice,
    Pluralize,
    EmptyArr,
    ScrollEventDirective,
    BreadcrumbComponent,
    CrumbComponent,
    ButtonComponent,
    ButtonTableComponent,
    ProgressBarComponent,
    VisuallyHiddenComponent,
    SelectComponent,
    IconInputComponent,
    IconComponent,
    UnstyledButtonComponent,
    SpacerComponent,
    NavBarComponent,
    NavLinkComponent,
    MobileNavBarComponent,
    SliderComponent,
    MessagesComponent,
    LoadingComponent,
    GifLoadingComponent,
    HorizonLoadingComponent,
    CircleLoadingComponent
  ],
  imports: [
    CommonModule,
    MaterialModule,
    FormsModule,
    RouterModule,
    NgxTranslateModule,
    ReactiveFormsModule,

  ],
  exports: [
    // QuillModule,
    ReactiveFormsModule,
    NgxTranslateModule,
    MaterialModule,
    FormsModule,
    RouterModule,
    FormatPrice,
    Pluralize,
    DateMonthYearPipe,
    EmptyArr,
    ScrollEventDirective,
    BreadcrumbComponent,
    CrumbComponent,
    ButtonComponent,
    ButtonTableComponent,
    ProgressBarComponent,
    VisuallyHiddenComponent,
    SelectComponent,
    IconInputComponent,
    IconComponent,
    UnstyledButtonComponent,
    SpacerComponent,
    NavBarComponent,
    NavLinkComponent,
    MobileNavBarComponent,
    SliderComponent,
    MessagesComponent,
    LoadingComponent,
    GifLoadingComponent,
    HorizonLoadingComponent,
    CircleLoadingComponent
  ]
})
export class SharedModule { }
