import { differenceInDays } from "date-fns";

export function getColour(variable: string) {
  return getComputedStyle(document.body).getPropertyValue(variable);
}

export function isNewShoe(releaseDate: number | Date) {
  return differenceInDays(new Date(), releaseDate) < 30;
}

