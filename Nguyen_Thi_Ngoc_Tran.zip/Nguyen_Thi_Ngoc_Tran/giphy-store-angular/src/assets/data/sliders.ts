import { ISlider } from "src/app/modules/shared/models";

export const SLIDERS
  : ISlider[] = [
    {
      header: "Best financial decision ever!",
      text: `Lorem ipsum dolor sit, amet consectetur adipisicing elit.
            Accusantium quas quisquam non? Quas voluptate nulla minima
            deleniti optio ullam nesciunt, numquam corporis et asperiores
            laboriosam sunt, praesentium suscipit blanditiis. Necessitatibus
            id alias reiciendis, perferendis facere pariatur dolore veniam
            autem esse non voluptatem saepe provident nihil molestiae.`,
      imgSrc: "assets/imgs/slider/user-1.jpg",
      authorName: "Aarav Lynn",
      authorLocation: "San Francisco, USA",
    },
    {
      header: "The last step to becoming a complete minimalist",
      text: `Quisquam itaque deserunt ullam, quia ea repellendus provident,
            ducimus neque ipsam modi voluptatibus doloremque, corrupti
            laborum. Incidunt numquam perferendis veritatis neque repellendus.
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Illo
            deserunt exercitationem deleniti.`,
      imgSrc: "assets/imgs/slider/user-2.jpg",
      authorName: "Miyah Miles",
      authorLocation: "London, UK",
    },
    {
      header: " Finally free from old-school banks",
      text: ` Debitis, nihil sit minus suscipit magni aperiam vel tenetur
            incidunt commodi architecto numquam omnis nulla autem,
            necessitatibus blanditiis modi similique quidem. Odio aliquam
            culpa dicta beatae quod maiores ipsa minus consequatur error sunt,
            deleniti saepe aliquid quos inventore sequi. Necessitatibus id
            alias reiciendis, perferendis facere.`,
      imgSrc: "assets/imgs/slider/user-3.jpg",
      authorName: "Francisco Gomes",
      authorLocation: "Lisbon, Portugal",
    }
  ]
